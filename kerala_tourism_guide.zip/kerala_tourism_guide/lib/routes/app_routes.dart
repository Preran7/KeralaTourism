import 'package:flutter/material.dart';
import '../presentation/reviews_and_ratings/reviews_and_ratings.dart';
import '../presentation/attraction_details/attraction_details.dart';
import '../presentation/navigation_interface/navigation_interface.dart';
import '../presentation/profile_and_settings/profile_and_settings.dart';
import '../presentation/map_dashboard/map_dashboard.dart';
import '../presentation/itinerary_planner/itinerary_planner.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String reviewsAndRatings = '/reviews-and-ratings';
  static const String attractionDetails = '/attraction-details';
  static const String navigationInterface = '/navigation-interface';
  static const String profileAndSettings = '/profile-and-settings';
  static const String mapDashboard = '/map-dashboard';
  static const String itineraryPlanner = '/itinerary-planner';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const ReviewsAndRatings(),
    reviewsAndRatings: (context) => const ReviewsAndRatings(),
    attractionDetails: (context) => const AttractionDetails(),
    navigationInterface: (context) => const NavigationInterface(),
    profileAndSettings: (context) => const ProfileAndSettings(),
    mapDashboard: (context) => const MapDashboard(),
    itineraryPlanner: (context) => const ItineraryPlanner(),
    // TODO: Add your other routes here
  };
}
