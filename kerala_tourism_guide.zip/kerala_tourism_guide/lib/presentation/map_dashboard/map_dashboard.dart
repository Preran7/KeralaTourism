import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/attraction_bottom_sheet.dart';
import './widgets/map_layer_toggle.dart';
import './widgets/map_view_widget.dart';
import './widgets/search_bar_widget.dart';
import './widgets/tab_navigation_widget.dart';
import './widgets/weather_widget.dart';

class MapDashboard extends StatefulWidget {
  const MapDashboard({Key? key}) : super(key: key);

  @override
  State<MapDashboard> createState() => _MapDashboardState();
}

class _MapDashboardState extends State<MapDashboard> {
  int _currentTabIndex = 0;
  MapType _currentMapType = MapType.normal;
  Set<Marker> _markers = {};
  LatLng? _currentLocation;
  final AudioRecorder _audioRecorder = AudioRecorder();
  bool _isRecording = false;

  // Mock data for attractions
  final List<Map<String, dynamic>> _nearbyAttractions = [
    {
      "id": 1,
      "name": "Munnar Tea Gardens",
      "category": "Nature & Wildlife",
      "rating": 4.8,
      "distance": "2.3 km",
      "latitude": 10.0889,
      "longitude": 77.0595,
      "image":
          "https://images.unsplash.com/photo-1544735716-392fe2489ffa?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "description":
          "Sprawling tea plantations with breathtaking mountain views and cool climate perfect for nature walks.",
      "estimatedTime": "15 mins",
      "type": "nature"
    },
    {
      "id": 2,
      "name": "Mattancherry Palace",
      "category": "Heritage Site",
      "rating": 4.6,
      "distance": "1.8 km",
      "latitude": 9.9312,
      "longitude": 76.2673,
      "image":
          "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "description":
          "Historic palace showcasing Kerala's royal heritage with traditional murals and artifacts.",
      "estimatedTime": "12 mins",
      "type": "heritage"
    },
    {
      "id": 3,
      "name": "Kathakali Centre",
      "category": "Cultural Center",
      "rating": 4.7,
      "distance": "3.1 km",
      "latitude": 9.9312,
      "longitude": 76.2673,
      "image":
          "https://images.unsplash.com/photo-1578662996442-48f60103fc96?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "description":
          "Traditional dance performances showcasing Kerala's rich cultural heritage and classical arts.",
      "estimatedTime": "18 mins",
      "type": "cultural"
    },
    {
      "id": 4,
      "name": "Backwater Cruise Point",
      "category": "Nature & Adventure",
      "rating": 4.9,
      "distance": "4.2 km",
      "latitude": 9.4981,
      "longitude": 76.3388,
      "image":
          "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "description":
          "Serene backwater experience through Kerala's famous network of canals and lagoons.",
      "estimatedTime": "25 mins",
      "type": "nature"
    },
    {
      "id": 5,
      "name": "Spice Market",
      "category": "Shopping & Culture",
      "rating": 4.4,
      "distance": "1.2 km",
      "latitude": 9.9312,
      "longitude": 76.2673,
      "image":
          "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "description":
          "Aromatic spice markets offering authentic Kerala spices and traditional cooking ingredients.",
      "estimatedTime": "8 mins",
      "type": "cultural"
    }
  ];

  // Mock weather data
  final Map<String, dynamic> _weatherData = {
    "temperature": 28,
    "condition": "Partly Cloudy",
    "humidity": 75,
    "windSpeed": "12 km/h"
  };

  @override
  void initState() {
    super.initState();
    _initializeMarkers();
  }

  void _initializeMarkers() {
    final Set<Marker> markers = {};

    for (final attraction in _nearbyAttractions) {
      markers.add(
        Marker(
          markerId: MarkerId(attraction['id'].toString()),
          position: LatLng(
            attraction['latitude'] as double,
            attraction['longitude'] as double,
          ),
          infoWindow: InfoWindow(
            title: attraction['name'] as String,
            snippet: '${attraction['category']} • ${attraction['distance']}',
          ),
          icon: _getMarkerIcon(attraction['type'] as String),
          onTap: () => _onMarkerTapped(attraction['id'].toString()),
        ),
      );
    }

    setState(() {
      _markers = markers;
    });
  }

  BitmapDescriptor _getMarkerIcon(String type) {
    // Return default marker for now - in production, use custom colored markers
    return BitmapDescriptor.defaultMarkerWithHue(type == 'heritage'
        ? BitmapDescriptor.hueRed
        : type == 'nature'
            ? BitmapDescriptor.hueGreen
            : BitmapDescriptor.hueBlue);
  }

  void _onLocationChanged(LatLng location) {
    setState(() {
      _currentLocation = location;
    });
  }

  void _onMarkerTapped(String markerId) {
    final attraction = _nearbyAttractions.firstWhere(
      (attr) => attr['id'].toString() == markerId,
    );

    // Show quick info card or navigate to attraction details
    _showAttractionQuickInfo(attraction);
  }

  void _showAttractionQuickInfo(Map<String, dynamic> attraction) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        margin: EdgeInsets.all(4.w),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: CustomImageWidget(
                imageUrl: attraction['image'] as String,
                width: double.infinity,
                height: 40.w,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              attraction['name'] as String,
              style: AppTheme.lightTheme.textTheme.titleLarge,
            ),
            SizedBox(height: 1.h),
            Text(
              attraction['description'] as String,
              style: AppTheme.lightTheme.textTheme.bodyMedium,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(height: 2.h),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/attraction-details');
                    },
                    child: const Text('View Details'),
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/navigation-interface');
                    },
                    child: const Text('Navigate'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _onSearch(String query) {
    // Implement search functionality
    // Filter attractions based on query
    if (query.isNotEmpty) {
      final filteredAttractions = _nearbyAttractions
          .where((attraction) =>
              (attraction['name'] as String)
                  .toLowerCase()
                  .contains(query.toLowerCase()) ||
              (attraction['category'] as String)
                  .toLowerCase()
                  .contains(query.toLowerCase()))
          .toList();

      // Update markers based on search results
      _updateMarkersForSearch(filteredAttractions);
    } else {
      _initializeMarkers();
    }
  }

  void _updateMarkersForSearch(List<Map<String, dynamic>> attractions) {
    final Set<Marker> markers = {};

    for (final attraction in attractions) {
      markers.add(
        Marker(
          markerId: MarkerId(attraction['id'].toString()),
          position: LatLng(
            attraction['latitude'] as double,
            attraction['longitude'] as double,
          ),
          infoWindow: InfoWindow(
            title: attraction['name'] as String,
            snippet: '${attraction['category']} • ${attraction['distance']}',
          ),
          icon: _getMarkerIcon(attraction['type'] as String),
          onTap: () => _onMarkerTapped(attraction['id'].toString()),
        ),
      );
    }

    setState(() {
      _markers = markers;
    });
  }

  Future<void> _onVoiceSearch() async {
    try {
      final hasPermission = await Permission.microphone.request();
      if (!hasPermission.isGranted) return;

      if (_isRecording) {
        final path = await _audioRecorder.stop();
        setState(() {
          _isRecording = false;
        });

        if (path != null) {
          // Process voice input - in production, integrate with speech-to-text
          _showVoiceSearchResult();
        }
      } else {
        String recordingPath;

        if (kIsWeb) {
          // For web, use a simple filename
          recordingPath = 'voice_search.wav';
          await _audioRecorder.start(
            const RecordConfig(encoder: AudioEncoder.wav),
            path: recordingPath,
          );
        } else {
          // For mobile, use temporary directory
          final directory = await getTemporaryDirectory();
          recordingPath =
              '${directory.path}/voice_search_${DateTime.now().millisecondsSinceEpoch}.m4a';
          await _audioRecorder.start(
            const RecordConfig(),
            path: recordingPath,
          );
        }

        setState(() {
          _isRecording = true;
        });

        // Auto-stop after 5 seconds
        Future.delayed(const Duration(seconds: 5), () async {
          if (_isRecording) {
            await _audioRecorder.stop();
            setState(() {
              _isRecording = false;
            });
            _showVoiceSearchResult();
          }
        });
      }
    } catch (e) {
      setState(() {
        _isRecording = false;
      });
    }
  }

  void _showVoiceSearchResult() {
    // Mock voice search result
    const mockResult = "tea gardens";
    _onSearch(mockResult);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Voice search: "$mockResult"'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _onAttractionTap(Map<String, dynamic> attraction) {
    Navigator.pushNamed(context, '/attraction-details');
  }

  void _onNavigateTap(Map<String, dynamic> attraction) {
    Navigator.pushNamed(context, '/navigation-interface');
  }

  void _onTabChanged(int index) {
    setState(() {
      _currentTabIndex = index;
    });

    // Navigate to other screens based on tab selection
    switch (index) {
      case 0:
        // Stay on map dashboard
        break;
      case 1:
        Navigator.pushNamed(context, '/itinerary-planner');
        break;
      case 2:
        Navigator.pushNamed(context, '/reviews-and-ratings');
        break;
      case 3:
        Navigator.pushNamed(context, '/profile-and-settings');
        break;
    }
  }

  void _onMapTypeChanged(MapType mapType) {
    setState(() {
      _currentMapType = mapType;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            // Main map view
            MapViewWidget(
              onLocationChanged: _onLocationChanged,
              onMarkerTapped: _onMarkerTapped,
              markers: _markers,
              mapType: _currentMapType,
            ),

            // Search bar at top
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: SearchBarWidget(
                onSearch: _onSearch,
                onVoiceSearch: _onVoiceSearch,
                onFilterTap: () {
                  // Show filter options
                },
              ),
            ),

            // Weather widget (top-left)
            Positioned(
              top: 8.h,
              left: 0,
              child: WeatherWidget(weatherData: _weatherData),
            ),

            // Map layer toggle (top-right)
            Positioned(
              top: 8.h,
              right: 0,
              child: MapLayerToggle(
                currentMapType: _currentMapType,
                onMapTypeChanged: _onMapTypeChanged,
              ),
            ),

            // Recording indicator
            if (_isRecording)
              Positioned(
                top: 15.h,
                left: 0,
                right: 0,
                child: Center(
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CustomIconWidget(
                          iconName: 'mic',
                          color: Colors.white,
                          size: 16,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          'Listening...',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

            // Bottom sheet with nearby attractions
            Positioned(
              bottom: 12.h,
              left: 0,
              right: 0,
              child: AttractionBottomSheet(
                nearbyAttractions: _nearbyAttractions,
                onAttractionTap: _onAttractionTap,
                onNavigateTap: _onNavigateTap,
              ),
            ),
          ],
        ),
      ),

      // Bottom navigation
      bottomNavigationBar: TabNavigationWidget(
        currentIndex: _currentTabIndex,
        onTabChanged: _onTabChanged,
      ),
    );
  }

  @override
  void dispose() {
    _audioRecorder.dispose();
    super.dispose();
  }
}
