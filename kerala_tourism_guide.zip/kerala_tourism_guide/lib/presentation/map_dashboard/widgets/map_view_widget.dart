import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class MapViewWidget extends StatefulWidget {
  final Function(LatLng) onLocationChanged;
  final Function(String) onMarkerTapped;
  final Set<Marker> markers;
  final MapType mapType;

  const MapViewWidget({
    Key? key,
    required this.onLocationChanged,
    required this.onMarkerTapped,
    required this.markers,
    this.mapType = MapType.normal,
  }) : super(key: key);

  @override
  State<MapViewWidget> createState() => _MapViewWidgetState();
}

class _MapViewWidgetState extends State<MapViewWidget> {
  GoogleMapController? _mapController;
  Position? _currentPosition;
  bool _isLocationPermissionGranted = false;

  static const LatLng _keralaCenter = LatLng(10.8505, 76.2711);

  @override
  void initState() {
    super.initState();
    _requestLocationPermission();
  }

  Future<void> _requestLocationPermission() async {
    final status = await Permission.location.request();
    if (status.isGranted) {
      setState(() {
        _isLocationPermissionGranted = true;
      });
      _getCurrentLocation();
    }
  }

  Future<void> _getCurrentLocation() async {
    try {
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      setState(() {
        _currentPosition = position;
      });

      final latLng = LatLng(position.latitude, position.longitude);
      widget.onLocationChanged(latLng);

      if (_mapController != null) {
        _mapController!.animateCamera(
          CameraUpdate.newLatLngZoom(latLng, 15.0),
        );
      }
    } catch (e) {
      // Handle location error silently
    }
  }

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;
    if (_currentPosition != null) {
      final latLng =
          LatLng(_currentPosition!.latitude, _currentPosition!.longitude);
      controller.animateCamera(
        CameraUpdate.newLatLngZoom(latLng, 15.0),
      );
    }
  }

  void _centerOnUserLocation() async {
    if (_currentPosition != null && _mapController != null) {
      final latLng =
          LatLng(_currentPosition!.latitude, _currentPosition!.longitude);
      await _mapController!.animateCamera(
        CameraUpdate.newLatLngZoom(latLng, 15.0),
      );
    } else {
      _getCurrentLocation();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GoogleMap(
          onMapCreated: _onMapCreated,
          initialCameraPosition: CameraPosition(
            target: _currentPosition != null
                ? LatLng(
                    _currentPosition!.latitude, _currentPosition!.longitude)
                : _keralaCenter,
            zoom: _currentPosition != null ? 15.0 : 8.0,
          ),
          markers: widget.markers,
          mapType: widget.mapType,
          myLocationEnabled: _isLocationPermissionGranted,
          myLocationButtonEnabled: false,
          zoomControlsEnabled: false,
          mapToolbarEnabled: false,
          onTap: (LatLng position) {
            // Handle map tap if needed
          },
          onLongPress: (LatLng position) {
            // Handle long press for waypoint creation
          },
        ),

        // Center on location FAB
        Positioned(
          bottom: 24.h,
          right: 4.w,
          child: FloatingActionButton(
            onPressed: _centerOnUserLocation,
            backgroundColor: AppTheme.lightTheme.colorScheme.primary,
            child: CustomIconWidget(
              iconName: 'my_location',
              color: AppTheme.lightTheme.colorScheme.onPrimary,
              size: 24,
            ),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }
}
