import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class MapLayerToggle extends StatelessWidget {
  final MapType currentMapType;
  final Function(MapType) onMapTypeChanged;

  const MapLayerToggle({
    Key? key,
    required this.currentMapType,
    required this.onMapTypeChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 4.w, top: 2.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: PopupMenuButton<MapType>(
        icon: CustomIconWidget(
          iconName: 'layers',
          color: AppTheme.lightTheme.colorScheme.primary,
          size: 24,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        itemBuilder: (context) => [
          _buildMapTypeItem(MapType.normal, 'Normal', 'map'),
          _buildMapTypeItem(MapType.satellite, 'Satellite', 'satellite_alt'),
          _buildMapTypeItem(MapType.terrain, 'Terrain', 'terrain'),
          _buildMapTypeItem(MapType.hybrid, 'Hybrid', 'layers'),
        ],
        onSelected: onMapTypeChanged,
      ),
    );
  }

  PopupMenuItem<MapType> _buildMapTypeItem(
    MapType mapType,
    String title,
    String iconName,
  ) {
    final isSelected = currentMapType == mapType;

    return PopupMenuItem<MapType>(
      value: mapType,
      child: Row(
        children: [
          CustomIconWidget(
            iconName: iconName,
            color: isSelected
                ? AppTheme.lightTheme.colorScheme.primary
                : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 20,
          ),
          SizedBox(width: 3.w),
          Text(
            title,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: isSelected
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.onSurface,
              fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
            ),
          ),
          const Spacer(),
          if (isSelected)
            CustomIconWidget(
              iconName: 'check',
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 16,
            ),
        ],
      ),
    );
  }
}
