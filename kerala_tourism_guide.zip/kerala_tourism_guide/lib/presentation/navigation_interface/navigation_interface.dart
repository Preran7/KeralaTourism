import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/navigation_controls_widget.dart';
import './widgets/navigation_header_widget.dart';
import './widgets/route_overview_widget.dart';
import './widgets/traffic_alert_widget.dart';

class NavigationInterface extends StatefulWidget {
  const NavigationInterface({Key? key}) : super(key: key);

  @override
  State<NavigationInterface> createState() => _NavigationInterfaceState();
}

class _NavigationInterfaceState extends State<NavigationInterface>
    with TickerProviderStateMixin {
  GoogleMapController? _mapController;
  Position? _currentPosition;
  bool _isVoiceEnabled = true;
  String _currentLanguage = 'English';
  bool _isNightMode = false;
  int _selectedRouteIndex = 0;
  bool _showRouteOverview = false;
  bool _showTrafficAlert = true;
  late AnimationController _alertAnimationController;
  late Animation<double> _alertAnimation;

  // Mock navigation data
  final List<Map<String, dynamic>> _mockRoutes = [
    {
      "name": "Via NH 66",
      "distance": "45.2 km",
      "time": "1h 15m",
      "traffic": "light",
    },
    {
      "name": "Via Backwaters Route",
      "distance": "52.8 km",
      "time": "1h 35m",
      "traffic": "moderate",
    },
    {
      "name": "Via City Center",
      "distance": "38.7 km",
      "time": "1h 45m",
      "traffic": "heavy",
    },
  ];

  final Map<String, dynamic> _mockNavigationData = {
    "nextTurn": "Turn right onto Mahatma Gandhi Road in 800m",
    "distance": "45.2 km remaining",
    "estimatedTime": "1h 15m",
    "totalDistance": "45.2 km",
    "totalTime": "1h 15m",
    "currentSpeedLimit": 60,
    "trafficAlert": {
      "type": "construction",
      "message": "Road construction ahead - expect delays",
      "distance": "2.5 km ahead",
    },
  };

  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};

  // Kerala coordinates for demo
  static const LatLng _keralaBounds = LatLng(10.8505, 76.2711);

  @override
  void initState() {
    super.initState();
    _initializeNavigation();
    _setupAnimations();
    _createMockRoute();
  }

  void _setupAnimations() {
    _alertAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _alertAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _alertAnimationController,
      curve: Curves.easeInOut,
    ));

    if (_showTrafficAlert) {
      _alertAnimationController.forward();
    }
  }

  Future<void> _initializeNavigation() async {
    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.whileInUse ||
          permission == LocationPermission.always) {
        _currentPosition = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
        );
        setState(() {});
      }
    } catch (e) {
      // Use Kerala bounds as fallback
      _currentPosition = Position(
        latitude: _keralaBounds.latitude,
        longitude: _keralaBounds.longitude,
        timestamp: DateTime.now(),
        accuracy: 0,
        altitude: 0,
        altitudeAccuracy: 0,
        heading: 0,
        headingAccuracy: 0,
        speed: 0,
        speedAccuracy: 0,
      );
      setState(() {});
    }
  }

  void _createMockRoute() {
    // Create route polyline
    _polylines.add(
      Polyline(
        polylineId: const PolylineId('route'),
        points: [
          _keralaBounds,
          LatLng(_keralaBounds.latitude + 0.1, _keralaBounds.longitude + 0.05),
          LatLng(_keralaBounds.latitude + 0.2, _keralaBounds.longitude + 0.1),
          LatLng(_keralaBounds.latitude + 0.3, _keralaBounds.longitude + 0.15),
        ],
        color: AppTheme.primaryLight,
        width: 5,
        patterns: [],
      ),
    );

    // Add destination marker
    _markers.add(
      Marker(
        markerId: const MarkerId('destination'),
        position: LatLng(
            _keralaBounds.latitude + 0.3, _keralaBounds.longitude + 0.15),
        infoWindow: const InfoWindow(
          title: 'Munnar Tea Gardens',
          snippet: 'Your destination',
        ),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
      ),
    );

    // Add current location marker
    if (_currentPosition != null) {
      _markers.add(
        Marker(
          markerId: const MarkerId('current_location'),
          position:
              LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
          infoWindow: const InfoWindow(title: 'Your Location'),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
        ),
      );
    }
  }

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;
    if (_isNightMode) {
      _mapController?.setMapStyle('''
        [
          {
            "elementType": "geometry",
            "stylers": [{"color": "#212121"}]
          },
          {
            "elementType": "labels.icon",
            "stylers": [{"visibility": "off"}]
          },
          {
            "elementType": "labels.text.fill",
            "stylers": [{"color": "#757575"}]
          }
        ]
      ''');
    }
  }

  void _endNavigation() {
    Navigator.pushReplacementNamed(context, '/map-dashboard');
  }

  void _toggleVoice() {
    setState(() {
      _isVoiceEnabled = !_isVoiceEnabled;
    });
    HapticFeedback.lightImpact();
  }

  void _changeLanguage() {
    final languages = ['English', 'Malayalam', 'Hindi', 'Tamil'];
    final currentIndex = languages.indexOf(_currentLanguage);
    final nextIndex = (currentIndex + 1) % languages.length;

    setState(() {
      _currentLanguage = languages[nextIndex];
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Voice guidance language changed to $_currentLanguage'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _toggleNightMode() {
    setState(() {
      _isNightMode = !_isNightMode;
    });

    if (_mapController != null) {
      if (_isNightMode) {
        _mapController?.setMapStyle('''
          [
            {
              "elementType": "geometry",
              "stylers": [{"color": "#212121"}]
            },
            {
              "elementType": "labels.text.fill",
              "stylers": [{"color": "#757575"}]
            }
          ]
        ''');
      } else {
        _mapController?.setMapStyle(null);
      }
    }
  }

  void _recenterMap() {
    if (_currentPosition != null && _mapController != null) {
      _mapController?.animateCamera(
        CameraUpdate.newLatLngZoom(
          LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
          16.0,
        ),
      );
    }
    HapticFeedback.lightImpact();
  }

  void _selectRoute(int index) {
    setState(() {
      _selectedRouteIndex = index;
    });
    HapticFeedback.selectionClick();
  }

  void _dismissTrafficAlert() {
    _alertAnimationController.reverse().then((_) {
      setState(() {
        _showTrafficAlert = false;
      });
    });
  }

  void _showEmergencyContacts() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Emergency Contacts',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimaryLight,
              ),
            ),
            SizedBox(height: 2.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'local_police',
                color: AppTheme.primaryLight,
                size: 24,
              ),
              title: const Text('Police'),
              subtitle: const Text('100'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'local_hospital',
                color: AppTheme.errorLight,
                size: 24,
              ),
              title: const Text('Medical Emergency'),
              subtitle: const Text('108'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'local_fire_department',
                color: AppTheme.secondaryLight,
                size: 24,
              ),
              title: const Text('Fire Department'),
              subtitle: const Text('101'),
              onTap: () => Navigator.pop(context),
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _alertAnimationController.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Google Map
          GoogleMap(
            onMapCreated: _onMapCreated,
            initialCameraPosition: CameraPosition(
              target: _currentPosition != null
                  ? LatLng(
                      _currentPosition!.latitude, _currentPosition!.longitude)
                  : _keralaBounds,
              zoom: 14.0,
            ),
            markers: _markers,
            polylines: _polylines,
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
            mapToolbarEnabled: false,
            compassEnabled: true,
            trafficEnabled: true,
            buildingsEnabled: true,
            mapType: MapType.normal,
            onTap: (_) {
              if (_showRouteOverview) {
                setState(() {
                  _showRouteOverview = false;
                });
              }
            },
          ),

          // Navigation Header
          NavigationHeaderWidget(
            nextTurn: _mockNavigationData["nextTurn"] as String,
            distance: _mockNavigationData["distance"] as String,
            estimatedTime: _mockNavigationData["estimatedTime"] as String,
            onEndNavigation: _endNavigation,
          ),

          // Navigation Controls
          NavigationControlsWidget(
            isVoiceEnabled: _isVoiceEnabled,
            currentLanguage: _currentLanguage,
            isNightMode: _isNightMode,
            currentSpeedLimit: _mockNavigationData["currentSpeedLimit"] as int,
            onVoiceToggle: _toggleVoice,
            onLanguageChange: _changeLanguage,
            onNightModeToggle: _toggleNightMode,
            onRecenter: _recenterMap,
          ),

          // Traffic Alert
          if (_showTrafficAlert)
            AnimatedBuilder(
              animation: _alertAnimation,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(0, -50 * (1 - _alertAnimation.value)),
                  child: Opacity(
                    opacity: _alertAnimation.value,
                    child: TrafficAlertWidget(
                      alertType: (_mockNavigationData["trafficAlert"]
                          as Map<String, dynamic>)["type"] as String,
                      alertMessage: (_mockNavigationData["trafficAlert"]
                          as Map<String, dynamic>)["message"] as String,
                      alertDistance: (_mockNavigationData["trafficAlert"]
                          as Map<String, dynamic>)["distance"] as String,
                      onDismiss: _dismissTrafficAlert,
                    ),
                  ),
                );
              },
            ),

          // Route Overview Panel
          if (_showRouteOverview)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: RouteOverviewWidget(
                totalDistance: _mockNavigationData["totalDistance"] as String,
                totalTime: _mockNavigationData["totalTime"] as String,
                alternativeRoutes: _mockRoutes,
                selectedRouteIndex: _selectedRouteIndex,
                onRouteSelected: _selectRoute,
                onEmergencyContact: _showEmergencyContacts,
              ),
            ),

          // Route Overview Toggle Button
          Positioned(
            bottom: 4.h,
            left: 4.w,
            child: FloatingActionButton(
              onPressed: () {
                setState(() {
                  _showRouteOverview = !_showRouteOverview;
                });
                HapticFeedback.lightImpact();
              },
              backgroundColor: AppTheme.lightTheme.colorScheme.surface,
              foregroundColor: AppTheme.primaryLight,
              elevation: 8,
              child: CustomIconWidget(
                iconName: _showRouteOverview ? 'expand_less' : 'expand_more',
                color: AppTheme.primaryLight,
                size: 28,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
