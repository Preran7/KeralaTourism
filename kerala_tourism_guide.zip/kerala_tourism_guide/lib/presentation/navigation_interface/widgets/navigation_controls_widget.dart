import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class NavigationControlsWidget extends StatelessWidget {
  final bool isVoiceEnabled;
  final String currentLanguage;
  final bool isNightMode;
  final int currentSpeedLimit;
  final VoidCallback onVoiceToggle;
  final VoidCallback onLanguageChange;
  final VoidCallback onNightModeToggle;
  final VoidCallback onRecenter;

  const NavigationControlsWidget({
    Key? key,
    required this.isVoiceEnabled,
    required this.currentLanguage,
    required this.isNightMode,
    required this.currentSpeedLimit,
    required this.onVoiceToggle,
    required this.onLanguageChange,
    required this.onNightModeToggle,
    required this.onRecenter,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Positioned(
      right: 4.w,
      top: 20.h,
      child: Column(
        children: [
          // Voice control
          Container(
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.shadowLight,
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: IconButton(
              onPressed: onVoiceToggle,
              icon: CustomIconWidget(
                iconName: isVoiceEnabled ? 'volume_up' : 'volume_off',
                color: isVoiceEnabled
                    ? AppTheme.primaryLight
                    : AppTheme.textSecondaryLight,
                size: 24,
              ),
              padding: EdgeInsets.all(3.w),
            ),
          ),

          SizedBox(height: 2.h),

          // Language selector
          Container(
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.shadowLight,
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: IconButton(
              onPressed: onLanguageChange,
              icon: CustomIconWidget(
                iconName: 'language',
                color: AppTheme.primaryLight,
                size: 24,
              ),
              padding: EdgeInsets.all(3.w),
            ),
          ),

          SizedBox(height: 2.h),

          // Night mode toggle
          Container(
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.shadowLight,
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: IconButton(
              onPressed: onNightModeToggle,
              icon: CustomIconWidget(
                iconName: isNightMode ? 'light_mode' : 'dark_mode',
                color: AppTheme.primaryLight,
                size: 24,
              ),
              padding: EdgeInsets.all(3.w),
            ),
          ),

          SizedBox(height: 2.h),

          // Recenter button
          Container(
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.shadowLight,
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: IconButton(
              onPressed: onRecenter,
              icon: CustomIconWidget(
                iconName: 'my_location',
                color: AppTheme.primaryLight,
                size: 24,
              ),
              padding: EdgeInsets.all(3.w),
            ),
          ),

          SizedBox(height: 2.h),

          // Speed limit indicator
          if (currentSpeedLimit > 0)
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.errorLight,
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.shadowLight,
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Text(
                    'SPEED',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.errorLight,
                      fontWeight: FontWeight.w600,
                      fontSize: 8.sp,
                    ),
                  ),
                  Text(
                    '$currentSpeedLimit',
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      color: AppTheme.errorLight,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    'LIMIT',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.errorLight,
                      fontWeight: FontWeight.w600,
                      fontSize: 8.sp,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
