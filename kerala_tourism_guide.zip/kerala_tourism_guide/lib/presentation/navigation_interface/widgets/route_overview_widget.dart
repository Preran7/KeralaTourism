import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class RouteOverviewWidget extends StatelessWidget {
  final String totalDistance;
  final String totalTime;
  final List<Map<String, dynamic>> alternativeRoutes;
  final int selectedRouteIndex;
  final Function(int) onRouteSelected;
  final VoidCallback onEmergencyContact;

  const RouteOverviewWidget({
    Key? key,
    required this.totalDistance,
    required this.totalTime,
    required this.alternativeRoutes,
    required this.selectedRouteIndex,
    required this.onRouteSelected,
    required this.onEmergencyContact,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 12,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          // Drag handle
          Center(
            child: Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.dividerLight,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          SizedBox(height: 2.h),

          // Route overview
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Route Overview',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textPrimaryLight,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'straighten',
                          color: AppTheme.primaryLight,
                          size: 18,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          totalDistance,
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme.textSecondaryLight,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        SizedBox(width: 6.w),
                        CustomIconWidget(
                          iconName: 'schedule',
                          color: AppTheme.primaryLight,
                          size: 18,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          totalTime,
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme.textSecondaryLight,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              ElevatedButton.icon(
                onPressed: onEmergencyContact,
                icon: CustomIconWidget(
                  iconName: 'emergency',
                  color: AppTheme.onErrorLight,
                  size: 18,
                ),
                label: Text(
                  'Emergency',
                  style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                    color: AppTheme.onErrorLight,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.errorLight,
                  foregroundColor: AppTheme.onErrorLight,
                  padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: 3.h),

          // Alternative routes
          alternativeRoutes.isNotEmpty
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Alternative Routes',
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textPrimaryLight,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    SizedBox(
                      height: 12.h,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: alternativeRoutes.length,
                        itemBuilder: (context, index) {
                          final route = alternativeRoutes[index];
                          final isSelected = index == selectedRouteIndex;

                          return GestureDetector(
                            onTap: () => onRouteSelected(index),
                            child: Container(
                              width: 40.w,
                              margin: EdgeInsets.only(right: 3.w),
                              padding: EdgeInsets.all(3.w),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? AppTheme.primaryLight
                                        .withValues(alpha: 0.1)
                                    : AppTheme.lightTheme.colorScheme.surface,
                                border: Border.all(
                                  color: isSelected
                                      ? AppTheme.primaryLight
                                      : AppTheme.dividerLight,
                                  width: isSelected ? 2 : 1,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      CustomIconWidget(
                                        iconName: route["traffic"] == "heavy"
                                            ? 'traffic'
                                            : 'route',
                                        color: route["traffic"] == "heavy"
                                            ? AppTheme.errorLight
                                            : AppTheme.primaryLight,
                                        size: 16,
                                      ),
                                      SizedBox(width: 2.w),
                                      Expanded(
                                        child: Text(
                                          route["name"] as String,
                                          style: AppTheme
                                              .lightTheme.textTheme.bodySmall
                                              ?.copyWith(
                                            fontWeight: FontWeight.w600,
                                            color: AppTheme.textPrimaryLight,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 1.h),
                                  Text(
                                    '${route["distance"]} • ${route["time"]}',
                                    style: AppTheme
                                        .lightTheme.textTheme.bodySmall
                                        ?.copyWith(
                                      color: AppTheme.textSecondaryLight,
                                    ),
                                  ),
                                  if (route["traffic"] != null) ...[
                                    SizedBox(height: 0.5.h),
                                    Container(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 2.w, vertical: 0.5.h),
                                      decoration: BoxDecoration(
                                        color: route["traffic"] == "heavy"
                                            ? AppTheme.errorLight
                                                .withValues(alpha: 0.1)
                                            : AppTheme.successLight
                                                .withValues(alpha: 0.1),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      child: Text(
                                        route["traffic"] == "heavy"
                                            ? 'Heavy Traffic'
                                            : 'Light Traffic',
                                        style: AppTheme
                                            .lightTheme.textTheme.bodySmall
                                            ?.copyWith(
                                          color: route["traffic"] == "heavy"
                                              ? AppTheme.errorLight
                                              : AppTheme.successLight,
                                          fontSize: 10.sp,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                )
              : const SizedBox.shrink(),
        ],
      ),
    );
  }
}
