import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TrafficAlertWidget extends StatelessWidget {
  final String alertType;
  final String alertMessage;
  final String alertDistance;
  final VoidCallback onDismiss;

  const TrafficAlertWidget({
    Key? key,
    required this.alertType,
    required this.alertMessage,
    required this.alertDistance,
    required this.onDismiss,
  }) : super(key: key);

  Color _getAlertColor() {
    switch (alertType.toLowerCase()) {
      case 'accident':
      case 'road_closed':
        return AppTheme.errorLight;
      case 'construction':
      case 'slow_traffic':
        return AppTheme.secondaryLight;
      case 'weather':
        return AppTheme.primaryLight;
      default:
        return AppTheme.textSecondaryLight;
    }
  }

  IconData _getAlertIcon() {
    switch (alertType.toLowerCase()) {
      case 'accident':
        return Icons.car_crash;
      case 'road_closed':
        return Icons.block;
      case 'construction':
        return Icons.construction;
      case 'slow_traffic':
        return Icons.traffic;
      case 'weather':
        return Icons.cloud;
      default:
        return Icons.warning;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: 12.h,
      left: 4.w,
      right: 4.w,
      child: Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _getAlertColor(),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: AppTheme.shadowLight,
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: _getAlertColor().withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                _getAlertIcon(),
                color: _getAlertColor(),
                size: 24,
              ),
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    alertMessage,
                    style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimaryLight,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 0.5.h),
                  Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'location_on',
                        color: _getAlertColor(),
                        size: 14,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        alertDistance,
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: AppTheme.textSecondaryLight,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            IconButton(
              onPressed: onDismiss,
              icon: CustomIconWidget(
                iconName: 'close',
                color: AppTheme.textSecondaryLight,
                size: 20,
              ),
              padding: EdgeInsets.all(1.w),
              constraints: const BoxConstraints(),
            ),
          ],
        ),
      ),
    );
  }
}
