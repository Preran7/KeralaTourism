import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/attraction_suggestions_widget.dart';
import './widgets/budget_tracker_widget.dart';
import './widgets/calendar_widget.dart';
import './widgets/day_timeline_widget.dart';
import './widgets/template_itineraries_widget.dart';

class ItineraryPlanner extends StatefulWidget {
  const ItineraryPlanner({Key? key}) : super(key: key);

  @override
  State<ItineraryPlanner> createState() => _ItineraryPlannerState();
}

class _ItineraryPlannerState extends State<ItineraryPlanner>
    with TickerProviderStateMixin {
  late TabController _tabController;
  DateTime _selectedDate = DateTime.now();
  int _currentBottomNavIndex = 3;

  // Mock data for itinerary planning
  final Map<String, List<Map<String, dynamic>>> _itineraryData = {
    '2025-01-17': [
      {
        'id': 1,
        'time': '09:00 AM',
        'title': 'Munnar Tea Gardens',
        'description':
            'Explore the lush green tea plantations and learn about tea processing',
        'duration': '3 hours',
        'cost': '₹500',
        'category': 'Nature',
      },
      {
        'id': 2,
        'time': '02:00 PM',
        'title': 'Mattupetty Dam',
        'description': 'Scenic dam with boating facilities and mountain views',
        'duration': '2 hours',
        'cost': '₹300',
        'category': 'Nature',
      },
      {
        'id': 3,
        'time': '05:00 PM',
        'title': 'Echo Point',
        'description': 'Famous viewpoint known for its natural echo phenomenon',
        'duration': '1 hour',
        'cost': '₹100',
        'category': 'Nature',
      },
    ],
    '2025-01-18': [
      {
        'id': 4,
        'time': '10:00 AM',
        'title': 'Alleppey Backwaters',
        'description':
            'Cruise through the serene backwaters on a traditional houseboat',
        'duration': '4 hours',
        'cost': '₹2000',
        'category': 'Cultural',
      },
    ],
  };

  final List<Map<String, dynamic>> _aiSuggestions = [
    {
      'id': 1,
      'name': 'Kumarakom Bird Sanctuary',
      'description':
          'A paradise for bird watchers with over 180 species of birds including migratory birds from Siberia.',
      'category': 'Nature',
      'rating': 4.5,
      'duration': '2-3 hours',
      'image':
          'https://images.pexels.com/photos/1108701/pexels-photo-1108701.jpeg?auto=compress&cs=tinysrgb&w=800',
    },
    {
      'id': 2,
      'name': 'Athirappilly Falls',
      'description':
          'Known as the Niagara of India, this spectacular waterfall is a must-visit natural wonder.',
      'category': 'Adventure',
      'rating': 4.7,
      'duration': '3-4 hours',
      'image':
          'https://images.pixabay.com/photo/2019/11/07/20/47/waterfall-4609749_1280.jpg',
    },
    {
      'id': 3,
      'name': 'Fort Kochi',
      'description':
          'Historic area with colonial architecture, Chinese fishing nets, and vibrant art scene.',
      'category': 'Heritage',
      'rating': 4.6,
      'duration': '4-5 hours',
      'image':
          'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=60',
    },
  ];

  final List<Map<String, dynamic>> _templateItineraries = [
    {
      'id': 1,
      'title': 'Kerala Backwaters 3-Day',
      'description':
          'Experience the serene backwaters of Kerala with houseboat stays and traditional cuisine.',
      'duration': '3 Days',
      'difficulty': 'Easy',
      'budget': '₹15,000 - ₹25,000',
      'rating': 4.8,
      'image':
          'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=60',
      'attractions': ['Alleppey', 'Kumarakom', 'Vembanad Lake', 'Kumbakonam'],
      'tags': ['Backwaters', 'Houseboat', 'Cultural', 'Relaxing'],
    },
    {
      'id': 2,
      'title': 'Cultural Heritage Week',
      'description':
          'Immerse yourself in Kerala\'s rich cultural heritage with temple visits and traditional performances.',
      'duration': '7 Days',
      'difficulty': 'Moderate',
      'budget': '₹30,000 - ₹45,000',
      'rating': 4.6,
      'image':
          'https://images.pexels.com/photos/3573382/pexels-photo-3573382.jpeg?auto=compress&cs=tinysrgb&w=800',
      'attractions': [
        'Guruvayur Temple',
        'Padmanabhaswamy Temple',
        'Kathakali Centre',
        'Mattancherry Palace'
      ],
      'tags': ['Heritage', 'Temples', 'Culture', 'Art'],
    },
    {
      'id': 3,
      'title': 'Adventure Kerala 5-Day',
      'description':
          'Thrilling adventure activities including trekking, wildlife safari, and water sports.',
      'duration': '5 Days',
      'difficulty': 'Challenging',
      'budget': '₹20,000 - ₹35,000',
      'rating': 4.7,
      'image':
          'https://images.pixabay.com/photo/2018/01/14/23/12/nature-3082832_1280.jpg',
      'attractions': [
        'Periyar Wildlife Sanctuary',
        'Munnar Hills',
        'Thekkady',
        'Wayanad'
      ],
      'tags': ['Adventure', 'Trekking', 'Wildlife', 'Nature'],
    },
  ];

  final List<Map<String, dynamic>> _expenses = [
    {
      'id': 1,
      'title': 'Houseboat Booking',
      'category': 'Accommodation',
      'amount': 2500.0,
      'date': '2025-01-15',
    },
    {
      'id': 2,
      'title': 'Local Transport',
      'category': 'Transport',
      'amount': 800.0,
      'date': '2025-01-16',
    },
    {
      'id': 3,
      'title': 'Traditional Meal',
      'category': 'Food',
      'amount': 450.0,
      'date': '2025-01-16',
    },
    {
      'id': 4,
      'title': 'Entry Tickets',
      'category': 'Activities',
      'amount': 300.0,
      'date': '2025-01-17',
    },
  ];

  double _totalBudget = 25000.0;
  double _spentAmount = 4050.0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildTabBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildPlannerTab(),
                _buildSuggestionsTab(),
                _buildBudgetTab(),
                _buildTemplatesTab(),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      elevation: 0,
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Container(
          margin: EdgeInsets.all(2.w),
          decoration: BoxDecoration(
            color:
                AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: CustomIconWidget(
            iconName: 'arrow_back',
            color: AppTheme.lightTheme.colorScheme.primary,
            size: 20,
          ),
        ),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Itinerary Planner',
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            'Plan your perfect Kerala journey',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
      actions: [
        GestureDetector(
          onTap: _showExportOptions,
          child: Container(
            margin: EdgeInsets.only(right: 4.w),
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.secondary
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomIconWidget(
              iconName: 'file_download',
              color: AppTheme.lightTheme.colorScheme.secondary,
              size: 20,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: AppTheme.lightTheme.shadowColor,
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.primary,
          borderRadius: BorderRadius.circular(8),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        labelColor: AppTheme.lightTheme.colorScheme.onPrimary,
        unselectedLabelColor: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
        labelStyle: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
          fontWeight: FontWeight.w600,
          fontSize: 10.sp,
        ),
        unselectedLabelStyle: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
          fontWeight: FontWeight.w400,
          fontSize: 10.sp,
        ),
        tabs: const [
          Tab(text: 'Planner'),
          Tab(text: 'Suggestions'),
          Tab(text: 'Budget'),
          Tab(text: 'Templates'),
        ],
      ),
    );
  }

  Widget _buildPlannerTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          CalendarWidget(
            selectedDate: _selectedDate,
            onDateSelected: (date) {
              setState(() {
                _selectedDate = date;
              });
            },
          ),
          SizedBox(height: 3.h),
          DayTimelineWidget(
            selectedDate: _selectedDate,
            dayActivities: _getDayActivities(_selectedDate),
            onActivityTap: _onActivityTap,
            onDeleteActivity: _onDeleteActivity,
          ),
        ],
      ),
    );
  }

  Widget _buildSuggestionsTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: AttractionSuggestionsWidget(
        suggestions: _aiSuggestions,
        onAttractionAdd: _onAttractionAdd,
      ),
    );
  }

  Widget _buildBudgetTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: BudgetTrackerWidget(
        totalBudget: _totalBudget,
        spentAmount: _spentAmount,
        expenses: _expenses,
        onAddExpense: _onAddExpense,
      ),
    );
  }

  Widget _buildTemplatesTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: TemplateItinerariesWidget(
        templates: _templateItineraries,
        onTemplateSelect: _onTemplateSelect,
      ),
    );
  }

  Widget _buildBottomNavigationBar() {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: AppTheme.lightTheme.shadowColor,
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: BottomNavigationBar(
        currentIndex: _currentBottomNavIndex,
        onTap: _onBottomNavTap,
        type: BottomNavigationBarType.fixed,
        backgroundColor: AppTheme.lightTheme.colorScheme.surface,
        selectedItemColor: AppTheme.lightTheme.colorScheme.primary,
        unselectedItemColor: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
        selectedLabelStyle: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
          fontWeight: FontWeight.w600,
        ),
        unselectedLabelStyle: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
          fontWeight: FontWeight.w400,
        ),
        items: [
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'map',
              color: _currentBottomNavIndex == 0
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            label: 'Map',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'place',
              color: _currentBottomNavIndex == 1
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            label: 'Attractions',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'navigation',
              color: _currentBottomNavIndex == 2
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            label: 'Navigate',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'event_note',
              color: _currentBottomNavIndex == 3
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            label: 'Planner',
          ),
          BottomNavigationBarItem(
            icon: CustomIconWidget(
              iconName: 'star',
              color: _currentBottomNavIndex == 4
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 24,
            ),
            label: 'Reviews',
          ),
        ],
      ),
    );
  }

  Widget _buildFloatingActionButton() {
    return FloatingActionButton(
      onPressed: _showQuickAddDialog,
      backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
      child: CustomIconWidget(
        iconName: 'add',
        color: AppTheme.lightTheme.colorScheme.onSecondary,
        size: 24,
      ),
    );
  }

  List<Map<String, dynamic>> _getDayActivities(DateTime date) {
    final dateKey =
        '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
    return _itineraryData[dateKey] ?? [];
  }

  void _onActivityTap(Map<String, dynamic> activity) {
    Navigator.pushNamed(context, '/attraction-details');
  }

  void _onDeleteActivity(Map<String, dynamic> activity) {
    setState(() {
      final dateKey =
          '${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}';
      _itineraryData[dateKey]
          ?.removeWhere((item) => item['id'] == activity['id']);
    });
  }

  void _onAttractionAdd(Map<String, dynamic> attraction) {
    setState(() {
      final dateKey =
          '${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}';
      if (_itineraryData[dateKey] == null) {
        _itineraryData[dateKey] = [];
      }
      _itineraryData[dateKey]!.add({
        'id': DateTime.now().millisecondsSinceEpoch,
        'time': '10:00 AM',
        'title': attraction['name'],
        'description': attraction['description'],
        'duration': attraction['duration'],
        'cost': '₹500',
        'category': attraction['category'],
      });
    });
  }

  void _onAddExpense(String title, double amount) {
    setState(() {
      _expenses.add({
        'id': DateTime.now().millisecondsSinceEpoch,
        'title': title,
        'category': 'Activities',
        'amount': amount,
        'date': DateTime.now().toString().split(' ')[0],
      });
      _spentAmount += amount;
    });
  }

  void _onTemplateSelect(Map<String, dynamic> template) {
    // Apply template to current itinerary
    setState(() {
      final attractions = template['attractions'] as List;
      final dateKey =
          '${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}';
      _itineraryData[dateKey] = attractions
          .asMap()
          .entries
          .map((entry) => {
                'id': entry.key + 1000,
                'time': '${9 + (entry.key * 2)}:00 AM',
                'title': entry.value as String,
                'description':
                    'Explore this amazing destination from our curated template',
                'duration': '2-3 hours',
                'cost': '₹500',
                'category': 'Template',
              })
          .toList();
    });
  }

  void _onBottomNavTap(int index) {
    setState(() {
      _currentBottomNavIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/map-dashboard');
        break;
      case 1:
        Navigator.pushNamed(context, '/attraction-details');
        break;
      case 2:
        Navigator.pushNamed(context, '/navigation-interface');
        break;
      case 3:
        // Current screen - do nothing
        break;
      case 4:
        Navigator.pushNamed(context, '/reviews-and-ratings');
        break;
    }
  }

  void _showQuickAddDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Quick Add Activity',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: CustomIconWidget(
                iconName: 'restaurant',
                color: AppTheme.lightTheme.colorScheme.secondary,
                size: 24,
              ),
              title: const Text('Add Meal Break'),
              onTap: () {
                Navigator.pop(context);
                _addQuickActivity(
                    'Lunch Break', 'Traditional Kerala meal', '1 hour', '₹300');
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'directions_car',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 24,
              ),
              title: const Text('Add Travel Time'),
              onTap: () {
                Navigator.pop(context);
                _addQuickActivity('Travel', 'Transportation between locations',
                    '30 mins', '₹100');
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'hotel',
                color: AppTheme.lightTheme.colorScheme.tertiary,
                size: 24,
              ),
              title: const Text('Add Rest Time'),
              onTap: () {
                Navigator.pop(context);
                _addQuickActivity(
                    'Rest Break', 'Relax and recharge', '1 hour', '₹0');
              },
            ),
          ],
        ),
      ),
    );
  }

  void _addQuickActivity(
      String title, String description, String duration, String cost) {
    setState(() {
      final dateKey =
          '${_selectedDate.year}-${_selectedDate.month.toString().padLeft(2, '0')}-${_selectedDate.day.toString().padLeft(2, '0')}';
      if (_itineraryData[dateKey] == null) {
        _itineraryData[dateKey] = [];
      }
      _itineraryData[dateKey]!.add({
        'id': DateTime.now().millisecondsSinceEpoch,
        'time': '12:00 PM',
        'title': title,
        'description': description,
        'duration': duration,
        'cost': cost,
        'category': 'Quick Add',
      });
    });
  }

  void _showExportOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.outline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Export Itinerary',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'picture_as_pdf',
                color: AppTheme.lightTheme.colorScheme.error,
                size: 24,
              ),
              title: const Text('Export as PDF'),
              subtitle: const Text('Detailed itinerary with maps'),
              onTap: () {
                Navigator.pop(context);
                // Export as PDF functionality
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'event',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 24,
              ),
              title: const Text('Add to Calendar'),
              subtitle: const Text('Sync with your device calendar'),
              onTap: () {
                Navigator.pop(context);
                // Add to calendar functionality
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'share',
                color: AppTheme.lightTheme.colorScheme.secondary,
                size: 24,
              ),
              title: const Text('Share Itinerary'),
              subtitle: const Text('Share with travel companions'),
              onTap: () {
                Navigator.pop(context);
                // Share functionality
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }
}
