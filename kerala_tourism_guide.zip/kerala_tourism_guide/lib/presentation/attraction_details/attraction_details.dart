import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/action_buttons.dart';
import './widgets/content_section.dart';
import './widgets/hero_image_carousel.dart';
import './widgets/related_attractions.dart';
import './widgets/review_card.dart';
import './widgets/sticky_header.dart';

class AttractionDetails extends StatefulWidget {
  const AttractionDetails({Key? key}) : super(key: key);

  @override
  State<AttractionDetails> createState() => _AttractionDetailsState();
}

class _AttractionDetailsState extends State<AttractionDetails> {
  final ScrollController _scrollController = ScrollController();
  bool _showStickyHeader = false;
  bool _isBookmarked = false;

  // Mock data for the attraction
  final Map<String, dynamic> _attractionData = {
    "id": 1,
    "name": "Munnar Tea Gardens",
    "rating": 4.8,
    "images": [
      "https://images.pexels.com/photos/4321802/pexels-photo-4321802.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "https://images.pexels.com/photos/1624496/pexels-photo-1624496.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      "https://images.pexels.com/photos/1624438/pexels-photo-1624438.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    ],
    "overview":
        """Munnar is a hill station and former resort for the British Raj elite. It's surrounded by rolling hills dotted with tea plantations established in the late 19th century. It's also home to several trekking and cycling routes, Anamudi Peak, fishing spots and a number of small towns and villages.""",
    "culturalSignificance":
        """The tea gardens of Munnar represent a unique blend of British colonial heritage and local Malayalam culture. Established in the 1870s by Scottish planter James Finlay, these plantations transformed the landscape and brought together diverse communities. The traditional tea-picking methods, passed down through generations, showcase the harmonious relationship between humans and nature that defines Kerala's cultural ethos.""",
    "bestTimeToVisit":
        """The ideal time to visit Munnar is from September to March when the weather is pleasant and cool. October to February offers the best climate with temperatures ranging from 15°C to 25°C. The monsoon season (June to September) brings lush greenery but can limit outdoor activities. Summer months (April to May) are warmer but still comfortable for hill station activities.""",
    "localCuisine":
        """Munnar offers a delightful mix of traditional Kerala cuisine and hill station specialties. Must-try dishes include Puttu with Kadala Curry, Appam with Stew, and fresh trout from local streams. The region is famous for its cardamom, which flavors many local dishes. Don't miss the traditional tea served with homemade snacks at local tea stalls, and try the unique hill station breakfast of bread, butter, and fresh mountain honey.""",
    "visitorTips":
        """Carry warm clothing as temperatures can drop significantly at night. Book accommodations in advance during peak season (December-January). Hire local guides for trekking to ensure safety and learn about local flora and fauna. Respect tea plantation workers and ask permission before photographing. Try the fresh tea directly from plantations for an authentic experience. Keep the environment clean and follow eco-friendly tourism practices.""",
  };

  final List<Map<String, dynamic>> _reviews = [
    {
      "id": 1,
      "userName": "Priya Sharma",
      "userAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "rating": 5,
      "date": "2 days ago",
      "comment":
          "Absolutely breathtaking! The tea gardens stretch as far as the eye can see. The morning mist rolling over the hills creates a magical atmosphere. Perfect place for photography and peaceful walks.",
      "likes": 24,
      "images": [
        "https://images.pexels.com/photos/4321802/pexels-photo-4321802.jpeg?auto=compress&cs=tinysrgb&w=400",
        "https://images.pexels.com/photos/1624496/pexels-photo-1624496.jpeg?auto=compress&cs=tinysrgb&w=400",
      ],
    },
    {
      "id": 2,
      "userName": "Rajesh Kumar",
      "userAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "rating": 4,
      "date": "1 week ago",
      "comment":
          "Great experience with family. Kids loved the tea factory tour. The local guide was very knowledgeable about the history and tea-making process. Accommodation was comfortable.",
      "likes": 18,
      "images": [],
    },
    {
      "id": 3,
      "userName": "Sarah Johnson",
      "userAvatar":
          "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
      "rating": 5,
      "date": "2 weeks ago",
      "comment":
          "One of the most serene places I've visited in India. The sunrise view from the top of the hills is unforgettable. Highly recommend staying overnight to experience the full beauty.",
      "likes": 31,
      "images": [
        "https://images.pexels.com/photos/1624438/pexels-photo-1624438.jpeg?auto=compress&cs=tinysrgb&w=400",
      ],
    },
  ];

  final List<Map<String, dynamic>> _relatedAttractions = [
    {
      "id": 2,
      "name": "Eravikulam National Park",
      "image":
          "https://images.pexels.com/photos/1624438/pexels-photo-1624438.jpeg?auto=compress&cs=tinysrgb&w=400",
      "distance": "15 km away",
      "rating": 4.6,
    },
    {
      "id": 3,
      "name": "Mattupetty Dam",
      "image":
          "https://images.pexels.com/photos/4321802/pexels-photo-4321802.jpeg?auto=compress&cs=tinysrgb&w=400",
      "distance": "8 km away",
      "rating": 4.3,
    },
    {
      "id": 4,
      "name": "Top Station",
      "image":
          "https://images.pexels.com/photos/1624496/pexels-photo-1624496.jpeg?auto=compress&cs=tinysrgb&w=400",
      "distance": "32 km away",
      "rating": 4.7,
    },
  ];

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.offset > 40.h && !_showStickyHeader) {
      setState(() {
        _showStickyHeader = true;
      });
    } else if (_scrollController.offset <= 40.h && _showStickyHeader) {
      setState(() {
        _showStickyHeader = false;
      });
    }
  }

  void _handleDirections() {
    Navigator.pushNamed(context, '/navigation-interface');
  }

  void _handleAudioGuide() {
    // Show audio guide options
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(5.w)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Audio Guide Languages',
              style: AppTheme.lightTheme.textTheme.titleLarge,
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'language',
                color: AppTheme.primaryLight,
                size: 6.w,
              ),
              title: Text('English'),
              trailing: CustomIconWidget(
                iconName: 'play_arrow',
                color: AppTheme.primaryLight,
                size: 6.w,
              ),
              onTap: () {
                Navigator.pop(context);
                _showToast('Starting English audio guide...');
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'language',
                color: AppTheme.primaryLight,
                size: 6.w,
              ),
              title: Text('Malayalam'),
              trailing: CustomIconWidget(
                iconName: 'play_arrow',
                color: AppTheme.primaryLight,
                size: 6.w,
              ),
              onTap: () {
                Navigator.pop(context);
                _showToast('Starting Malayalam audio guide...');
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'language',
                color: AppTheme.primaryLight,
                size: 6.w,
              ),
              title: Text('Hindi'),
              trailing: CustomIconWidget(
                iconName: 'play_arrow',
                color: AppTheme.primaryLight,
                size: 6.w,
              ),
              onTap: () {
                Navigator.pop(context);
                _showToast('Starting Hindi audio guide...');
              },
            ),
          ],
        ),
      ),
    );
  }

  void _handleShare() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(5.w)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Share ${_attractionData['name']}',
              style: AppTheme.lightTheme.textTheme.titleLarge,
            ),
            SizedBox(height: 3.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildShareOption('WhatsApp', 'message', () {
                  Navigator.pop(context);
                  _showToast('Shared to WhatsApp');
                }),
                _buildShareOption('Facebook', 'facebook', () {
                  Navigator.pop(context);
                  _showToast('Shared to Facebook');
                }),
                _buildShareOption('Instagram', 'camera_alt', () {
                  Navigator.pop(context);
                  _showToast('Shared to Instagram');
                }),
                _buildShareOption('Copy Link', 'link', () {
                  Navigator.pop(context);
                  Clipboard.setData(ClipboardData(
                      text: 'https://kerala-tourism.com/munnar-tea-gardens'));
                  _showToast('Link copied to clipboard');
                }),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildShareOption(String title, String iconName, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.primaryLight.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(3.w),
            ),
            child: CustomIconWidget(
              iconName: iconName,
              color: AppTheme.primaryLight,
              size: 6.w,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            title,
            style: AppTheme.lightTheme.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }

  void _handleFindGuide() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(5.w)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Available Guides',
              style: AppTheme.lightTheme.textTheme.titleLarge,
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CircleAvatar(
                backgroundImage: NetworkImage(
                    'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png'),
              ),
              title: Text('Ravi Menon'),
              subtitle: Text('Certified Guide • 4.9 ⭐ • ₹500/day'),
              trailing: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  _showToast('Guide booking request sent');
                },
                child: Text('Book'),
              ),
            ),
            ListTile(
              leading: CircleAvatar(
                backgroundImage: NetworkImage(
                    'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png'),
              ),
              title: Text('Lakshmi Nair'),
              subtitle: Text('Certified Guide • 4.8 ⭐ • ₹450/day'),
              trailing: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  _showToast('Guide booking request sent');
                },
                child: Text('Book'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _handleBookmark() {
    setState(() {
      _isBookmarked = !_isBookmarked;
    });
    _showToast(_isBookmarked ? 'Added to bookmarks' : 'Removed from bookmarks');
  }

  void _handleWriteReview() {
    Navigator.pushNamed(context, '/reviews-and-ratings');
  }

  void _handleRelatedAttractionTap(Map<String, dynamic> attraction) {
    _showToast('Opening ${attraction['name']}...');
  }

  void _showToast(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: Stack(
        children: [
          CustomScrollView(
            controller: _scrollController,
            slivers: [
              SliverToBoxAdapter(
                child: HeroImageCarousel(
                  images: (_attractionData['images'] as List).cast<String>(),
                  attractionName: _attractionData['name'] as String,
                ),
              ),
              SliverToBoxAdapter(
                child: SizedBox(height: 2.h),
              ),
              SliverToBoxAdapter(
                child: ActionButtons(
                  onDirectionsTap: _handleDirections,
                  onAudioGuideTap: _handleAudioGuide,
                  onShareTap: _handleShare,
                  onFindGuideTap: _handleFindGuide,
                ),
              ),
              SliverToBoxAdapter(
                child: ContentSection(
                  title: 'Overview',
                  content: _attractionData['overview'] as String,
                  isExpanded: true,
                ),
              ),
              SliverToBoxAdapter(
                child: ContentSection(
                  title: 'Cultural Significance',
                  content: _attractionData['culturalSignificance'] as String,
                ),
              ),
              SliverToBoxAdapter(
                child: ContentSection(
                  title: 'Best Time to Visit',
                  content: _attractionData['bestTimeToVisit'] as String,
                ),
              ),
              SliverToBoxAdapter(
                child: ContentSection(
                  title: 'Local Cuisine',
                  content: _attractionData['localCuisine'] as String,
                ),
              ),
              SliverToBoxAdapter(
                child: ContentSection(
                  title: 'Visitor Tips',
                  content: _attractionData['visitorTips'] as String,
                ),
              ),
              SliverToBoxAdapter(
                child: Container(
                  padding: EdgeInsets.all(4.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Reviews (${_reviews.length})',
                        style: AppTheme.lightTheme.textTheme.titleLarge,
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pushNamed(context, '/reviews-and-ratings');
                        },
                        child: Text('View All'),
                      ),
                    ],
                  ),
                ),
              ),
              SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    return ReviewCard(review: _reviews[index]);
                  },
                  childCount: _reviews.length > 2 ? 2 : _reviews.length,
                ),
              ),
              SliverToBoxAdapter(
                child: RelatedAttractions(
                  attractions: _relatedAttractions,
                  onAttractionTap: _handleRelatedAttractionTap,
                ),
              ),
              SliverToBoxAdapter(
                child: SizedBox(height: 10.h),
              ),
            ],
          ),
          if (_showStickyHeader)
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: SafeArea(
                child: StickyHeader(
                  attractionName: _attractionData['name'] as String,
                  rating: (_attractionData['rating'] as num).toDouble(),
                  isBookmarked: _isBookmarked,
                  onBookmarkTap: _handleBookmark,
                ),
              ),
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _handleWriteReview,
        icon: CustomIconWidget(
          iconName: 'rate_review',
          color: AppTheme.lightTheme.colorScheme.onSecondary,
          size: 5.w,
        ),
        label: Text('Write Review'),
      ),
    );
  }
}
