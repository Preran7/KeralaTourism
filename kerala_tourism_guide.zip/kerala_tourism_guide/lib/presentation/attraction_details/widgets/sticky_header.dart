import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class StickyHeader extends StatelessWidget {
  final String attractionName;
  final double rating;
  final bool isBookmarked;
  final VoidCallback onBookmarkTap;

  const StickyHeader({
    Key? key,
    required this.attractionName,
    required this.rating,
    required this.isBookmarked,
    required this.onBookmarkTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  attractionName,
                  style: AppTheme.lightTheme.textTheme.titleLarge,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                SizedBox(height: 1.h),
                Row(
                  children: [
                    ...List.generate(5, (index) {
                      return CustomIconWidget(
                        iconName:
                            index < rating.floor() ? 'star' : 'star_border',
                        color: AppTheme.secondaryLight,
                        size: 4.w,
                      );
                    }),
                    SizedBox(width: 2.w),
                    Text(
                      rating.toStringAsFixed(1),
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: onBookmarkTap,
            child: Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: isBookmarked
                    ? AppTheme.primaryLight.withValues(alpha: 0.1)
                    : AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(2.w),
                border: Border.all(
                  color: isBookmarked
                      ? AppTheme.primaryLight
                      : AppTheme.dividerLight,
                ),
              ),
              child: CustomIconWidget(
                iconName: isBookmarked ? 'bookmark' : 'bookmark_border',
                color: isBookmarked
                    ? AppTheme.primaryLight
                    : AppTheme.textSecondaryLight,
                size: 6.w,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
