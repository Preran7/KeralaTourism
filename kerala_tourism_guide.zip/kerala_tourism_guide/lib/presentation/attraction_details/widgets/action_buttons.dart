import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ActionButtons extends StatelessWidget {
  final VoidCallback onDirectionsTap;
  final VoidCallback onAudioGuideTap;
  final VoidCallback onShareTap;
  final VoidCallback onFindGuideTap;

  const ActionButtons({
    Key? key,
    required this.onDirectionsTap,
    required this.onAudioGuideTap,
    required this.onShareTap,
    required this.onFindGuideTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onDirectionsTap,
                  icon: CustomIconWidget(
                    iconName: 'directions',
                    color: AppTheme.lightTheme.colorScheme.onPrimary,
                    size: 5.w,
                  ),
                  label: Text('Get Directions'),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 2.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2.w),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onAudioGuideTap,
                  icon: CustomIconWidget(
                    iconName: 'headphones',
                    color: AppTheme.primaryLight,
                    size: 5.w,
                  ),
                  label: Text('Audio Guide'),
                  style: OutlinedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 2.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2.w),
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onShareTap,
                  icon: CustomIconWidget(
                    iconName: 'share',
                    color: AppTheme.primaryLight,
                    size: 5.w,
                  ),
                  label: Text('Share'),
                  style: OutlinedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 2.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2.w),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onFindGuideTap,
                  icon: CustomIconWidget(
                    iconName: 'person_search',
                    color: AppTheme.primaryLight,
                    size: 5.w,
                  ),
                  label: Text('Find Guide'),
                  style: OutlinedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 2.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(2.w),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
