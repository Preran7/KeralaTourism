import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ReviewsSummaryWidget extends StatelessWidget {
  final Map<String, dynamic> summaryData;

  const ReviewsSummaryWidget({
    Key? key,
    required this.summaryData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final averageRating = summaryData['averageRating']?.toDouble() ?? 0.0;
    final totalReviews = summaryData['totalReviews'] ?? 0;
    final ratingDistribution =
        summaryData['ratingDistribution'] as Map<String, int>? ?? {};

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                flex: 2,
                child: _buildOverallRating(averageRating, totalReviews),
              ),
              SizedBox(width: 4.w),
              Expanded(
                flex: 3,
                child:
                    _buildRatingDistribution(ratingDistribution, totalReviews),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          _buildCategoryRatings(),
        ],
      ),
    );
  }

  Widget _buildOverallRating(double averageRating, int totalReviews) {
    return Column(
      children: [
        Text(
          averageRating.toStringAsFixed(1),
          style: AppTheme.lightTheme.textTheme.displaySmall?.copyWith(
            fontWeight: FontWeight.w700,
            color: AppTheme.lightTheme.colorScheme.primary,
          ),
        ),
        SizedBox(height: 1.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(5, (index) {
            return CustomIconWidget(
              iconName: index < averageRating.floor() ? 'star' : 'star_border',
              size: 5.w,
              color: index < averageRating.floor()
                  ? AppTheme.lightTheme.colorScheme.secondary
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            );
          }),
        ),
        SizedBox(height: 1.h),
        Text(
          '$totalReviews reviews',
          style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }

  Widget _buildRatingDistribution(
      Map<String, int> distribution, int totalReviews) {
    return Column(
      children: List.generate(5, (index) {
        final starCount = 5 - index;
        final count = distribution['$starCount'] ?? 0;
        final percentage = totalReviews > 0 ? (count / totalReviews) : 0.0;

        return Padding(
          padding: EdgeInsets.symmetric(vertical: 0.5.h),
          child: Row(
            children: [
              Text(
                '$starCount',
                style: AppTheme.lightTheme.textTheme.labelMedium,
              ),
              SizedBox(width: 1.w),
              CustomIconWidget(
                iconName: 'star',
                size: 3.w,
                color: AppTheme.lightTheme.colorScheme.secondary,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: LinearProgressIndicator(
                  value: percentage,
                  backgroundColor: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                  valueColor: AlwaysStoppedAnimation<Color>(
                    AppTheme.lightTheme.colorScheme.primary,
                  ),
                  minHeight: 1.h,
                ),
              ),
              SizedBox(width: 2.w),
              Text(
                '$count',
                style: AppTheme.lightTheme.textTheme.labelSmall,
              ),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildCategoryRatings() {
    final categories = [
      {
        'label': 'Food',
        'rating': summaryData['foodRating']?.toDouble() ?? 0.0,
        'icon': 'restaurant'
      },
      {
        'label': 'Accessibility',
        'rating': summaryData['accessibilityRating']?.toDouble() ?? 0.0,
        'icon': 'accessible'
      },
      {
        'label': 'Guide Service',
        'rating': summaryData['guideRating']?.toDouble() ?? 0.0,
        'icon': 'person'
      },
      {
        'label': 'Value',
        'rating': summaryData['valueRating']?.toDouble() ?? 0.0,
        'icon': 'attach_money'
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Category Ratings',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 2.h),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 3,
            crossAxisSpacing: 3.w,
            mainAxisSpacing: 2.h,
          ),
          itemCount: categories.length,
          itemBuilder: (context, index) {
            final category = categories[index];
            final rating = category['rating'] as double;

            return Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: category['icon'] as String,
                    size: 5.w,
                    color: AppTheme.lightTheme.colorScheme.primary,
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          category['label'] as String,
                          style: AppTheme.lightTheme.textTheme.labelMedium
                              ?.copyWith(
                            fontWeight: FontWeight.w500,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        Row(
                          children: [
                            Text(
                              rating.toStringAsFixed(1),
                              style: AppTheme.lightTheme.textTheme.labelSmall
                                  ?.copyWith(
                                fontWeight: FontWeight.w600,
                                color: AppTheme.lightTheme.colorScheme.primary,
                              ),
                            ),
                            SizedBox(width: 1.w),
                            CustomIconWidget(
                              iconName: 'star',
                              size: 3.w,
                              color: AppTheme.lightTheme.colorScheme.secondary,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }
}
