import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ReviewCardWidget extends StatefulWidget {
  final Map<String, dynamic> review;
  final VoidCallback? onHelpfulPressed;
  final VoidCallback? onReportPressed;

  const ReviewCardWidget({
    Key? key,
    required this.review,
    this.onHelpfulPressed,
    this.onReportPressed,
  }) : super(key: key);

  @override
  State<ReviewCardWidget> createState() => _ReviewCardWidgetState();
}

class _ReviewCardWidgetState extends State<ReviewCardWidget> {
  bool _isExpanded = false;
  bool _isHelpful = false;
  int _currentPhotoIndex = 0;

  @override
  Widget build(BuildContext context) {
    final review = widget.review;
    final photos = (review['photos'] as List?) ?? [];
    final ratings = review['ratings'] as Map<String, dynamic>? ?? {};

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildUserHeader(),
            SizedBox(height: 2.h),
            _buildRatings(ratings),
            SizedBox(height: 2.h),
            _buildReviewText(),
            if (photos.isNotEmpty) ...[
              SizedBox(height: 2.h),
              _buildPhotoGallery(photos),
            ],
            SizedBox(height: 2.h),
            _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  Widget _buildUserHeader() {
    return Row(
      children: [
        CircleAvatar(
          radius: 6.w,
          child: CustomImageWidget(
            imageUrl: widget.review['userAvatar'] as String? ?? '',
            width: 12.w,
            height: 12.w,
            fit: BoxFit.cover,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.review['userName'] as String? ?? 'Anonymous',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 0.5.h),
              Row(
                children: [
                  CustomIconWidget(
                    iconName: 'calendar_today',
                    size: 4.w,
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                  SizedBox(width: 1.w),
                  Text(
                    widget.review['visitDate'] as String? ?? '',
                    style: AppTheme.lightTheme.textTheme.bodySmall,
                  ),
                  SizedBox(width: 3.w),
                  Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      widget.review['travelerType'] as String? ?? 'Solo',
                      style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                        color:
                            AppTheme.lightTheme.colorScheme.onPrimaryContainer,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        PopupMenuButton<String>(
          onSelected: (value) {
            if (value == 'report' && widget.onReportPressed != null) {
              widget.onReportPressed!();
            }
          },
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'report',
              child: Row(
                children: [
                  Icon(Icons.flag_outlined, size: 18),
                  SizedBox(width: 8),
                  Text('Report'),
                ],
              ),
            ),
          ],
          child: CustomIconWidget(
            iconName: 'more_vert',
            size: 5.w,
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }

  Widget _buildRatings(Map<String, dynamic> ratings) {
    return Column(
      children: [
        Row(
          children: [
            _buildStarRating('Overall', ratings['overall']?.toDouble() ?? 0.0),
            SizedBox(width: 4.w),
            _buildStarRating('Food', ratings['food']?.toDouble() ?? 0.0),
          ],
        ),
        SizedBox(height: 1.h),
        Row(
          children: [
            _buildStarRating(
                'Accessibility', ratings['accessibility']?.toDouble() ?? 0.0),
            SizedBox(width: 4.w),
            _buildStarRating('Guide', ratings['guide']?.toDouble() ?? 0.0),
          ],
        ),
      ],
    );
  }

  Widget _buildStarRating(String label, double rating) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: AppTheme.lightTheme.textTheme.labelMedium,
          ),
          SizedBox(height: 0.5.h),
          Row(
            children: List.generate(5, (index) {
              return CustomIconWidget(
                iconName: index < rating.floor() ? 'star' : 'star_border',
                size: 4.w,
                color: index < rating.floor()
                    ? AppTheme.lightTheme.colorScheme.secondary
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildReviewText() {
    final reviewText = widget.review['reviewText'] as String? ?? '';
    final shouldShowReadMore = reviewText.length > 150;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          _isExpanded || !shouldShowReadMore
              ? reviewText
              : '${reviewText.substring(0, 150)}...',
          style: AppTheme.lightTheme.textTheme.bodyMedium,
        ),
        if (shouldShowReadMore) ...[
          SizedBox(height: 1.h),
          GestureDetector(
            onTap: () => setState(() => _isExpanded = !_isExpanded),
            child: Text(
              _isExpanded ? 'Read Less' : 'Read More',
              style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.primary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildPhotoGallery(List photos) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Photos (${photos.length})',
          style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        SizedBox(
          height: 20.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: photos.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () => _showFullScreenPhoto(photos, index),
                child: Container(
                  width: 30.w,
                  margin: EdgeInsets.only(right: 2.w),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.1),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: CustomImageWidget(
                      imageUrl: photos[index] as String,
                      width: 30.w,
                      height: 20.h,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildActionButtons() {
    return Row(
      children: [
        GestureDetector(
          onTap: () {
            setState(() => _isHelpful = !_isHelpful);
            if (widget.onHelpfulPressed != null) {
              widget.onHelpfulPressed!();
            }
          },
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: _isHelpful
                  ? AppTheme.lightTheme.colorScheme.primaryContainer
                  : AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: _isHelpful
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.colorScheme.outline,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                CustomIconWidget(
                  iconName: 'thumb_up',
                  size: 4.w,
                  color: _isHelpful
                      ? AppTheme.lightTheme.colorScheme.primary
                      : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
                SizedBox(width: 1.w),
                Text(
                  'Helpful (${widget.review['helpfulCount'] ?? 0})',
                  style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                    color: _isHelpful
                        ? AppTheme.lightTheme.colorScheme.primary
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ),
        const Spacer(),
        if (widget.review['hasResponse'] == true) ...[
          Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.tertiaryContainer,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                CustomIconWidget(
                  iconName: 'reply',
                  size: 4.w,
                  color: AppTheme.lightTheme.colorScheme.onTertiaryContainer,
                ),
                SizedBox(width: 1.w),
                Text(
                  'Response',
                  style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onTertiaryContainer,
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  void _showFullScreenPhoto(List photos, int initialIndex) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: IconButton(
              icon: const Icon(Icons.close, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
            title: Text(
              '${initialIndex + 1} of ${photos.length}',
              style: const TextStyle(color: Colors.white),
            ),
          ),
          body: PageView.builder(
            controller: PageController(initialPage: initialIndex),
            itemCount: photos.length,
            onPageChanged: (index) {
              setState(() => _currentPhotoIndex = index);
            },
            itemBuilder: (context, index) {
              return Center(
                child: InteractiveViewer(
                  child: CustomImageWidget(
                    imageUrl: photos[index] as String,
                    width: 100.w,
                    height: 80.h,
                    fit: BoxFit.contain,
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
