import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/filter_chips_widget.dart';
import './widgets/review_card_widget.dart';
import './widgets/reviews_summary_widget.dart';
import './widgets/write_review_bottom_sheet.dart';

class ReviewsAndRatings extends StatefulWidget {
  const ReviewsAndRatings({Key? key}) : super(key: key);

  @override
  State<ReviewsAndRatings> createState() => _ReviewsAndRatingsState();
}

class _ReviewsAndRatingsState extends State<ReviewsAndRatings> {
  String _selectedFilter = 'recent';
  List<Map<String, dynamic>> _filteredReviews = [];
  bool _isLoading = false;

  // Mock data for reviews
  final List<Map<String, dynamic>> _allReviews = [
    {
      'id': 1,
      'userName': 'Priya Sharma',
      'userAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'visitDate': '15 Sep 2025',
      'travelerType': 'Family',
      'reviewText':
          'Absolutely stunning backwaters! The houseboat experience was magical with traditional Kerala cuisine. Our guide Ravi was incredibly knowledgeable about local history and culture. The sunset views were breathtaking and the kids loved spotting different birds. Highly recommend the traditional Kathakali performance in the evening.',
      'ratings': {
        'overall': 5.0,
        'food': 4.5,
        'accessibility': 4.0,
        'guide': 5.0,
      },
      'photos': [
        'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=800',
        'https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=800',
        'https://images.unsplash.com/photo-1571115764595-644a1f56a55c?w=800',
      ],
      'helpfulCount': 24,
      'hasResponse': true,
      'timestamp': DateTime.now().subtract(const Duration(days: 2)),
    },
    {
      'id': 2,
      'userName': 'James Wilson',
      'userAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'visitDate': '12 Sep 2025',
      'travelerType': 'Solo',
      'reviewText':
          'Kerala\'s spice plantations are a sensory delight! The aroma of cardamom, pepper, and cinnamon fills the air. Our plantation walk was educational and the fresh spices we bought were authentic. The traditional lunch served on banana leaves was exceptional.',
      'ratings': {
        'overall': 4.5,
        'food': 5.0,
        'accessibility': 3.5,
        'guide': 4.0,
      },
      'photos': [
        'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=800',
        'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800',
      ],
      'helpfulCount': 18,
      'hasResponse': false,
      'timestamp': DateTime.now().subtract(const Duration(days: 5)),
    },
    {
      'id': 3,
      'userName': 'Maria Rodriguez',
      'userAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'visitDate': '10 Sep 2025',
      'travelerType': 'Couple',
      'reviewText':
          'Fort Kochi is a perfect blend of Portuguese, Dutch, and British colonial architecture. The Chinese fishing nets at sunset create a romantic atmosphere. Street food was amazing, especially the fish curry and appam. Perfect for couples seeking cultural immersion.',
      'ratings': {
        'overall': 4.8,
        'food': 4.5,
        'accessibility': 4.5,
        'guide': 4.0,
      },
      'photos': [
        'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800',
      ],
      'helpfulCount': 31,
      'hasResponse': true,
      'timestamp': DateTime.now().subtract(const Duration(days: 7)),
    },
    {
      'id': 4,
      'userName': 'Rajesh Kumar',
      'userAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'visitDate': '08 Sep 2025',
      'travelerType': 'Family',
      'reviewText':
          'Munnar\'s tea gardens are breathtaking! The cool climate and rolling green hills provide a perfect escape from city heat. Tea museum was informative and the fresh tea tasting was delightful. Kids enjoyed the elephant ride at the nearby sanctuary.',
      'ratings': {
        'overall': 4.2,
        'food': 3.8,
        'accessibility': 4.2,
        'guide': 4.5,
      },
      'photos': [
        'https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=800',
        'https://images.unsplash.com/photo-1571115764595-644a1f56a55c?w=800',
      ],
      'helpfulCount': 15,
      'hasResponse': false,
      'timestamp': DateTime.now().subtract(const Duration(days: 9)),
    },
    {
      'id': 5,
      'userName': 'Sarah Johnson',
      'userAvatar':
          'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
      'visitDate': '05 Sep 2025',
      'travelerType': 'Solo',
      'reviewText':
          'Thekkady\'s Periyar Wildlife Sanctuary exceeded expectations! Spotted wild elephants, deer, and various bird species during the boat safari. The spice garden tour was educational and the bamboo rafting adventure was thrilling. Accommodation was comfortable with authentic Kerala hospitality.',
      'ratings': {
        'overall': 4.7,
        'food': 4.2,
        'accessibility': 3.8,
        'guide': 5.0,
      },
      'photos': [
        'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=800',
      ],
      'helpfulCount': 22,
      'hasResponse': true,
      'timestamp': DateTime.now().subtract(const Duration(days: 12)),
    },
  ];

  // Mock summary data
  final Map<String, dynamic> _summaryData = {
    'averageRating': 4.6,
    'totalReviews': 127,
    'ratingDistribution': {
      '5': 68,
      '4': 35,
      '3': 18,
      '2': 4,
      '1': 2,
    },
    'foodRating': 4.4,
    'accessibilityRating': 4.1,
    'guideRating': 4.5,
    'valueRating': 4.3,
  };

  @override
  void initState() {
    super.initState();
    _filteredReviews = List.from(_allReviews);
  }

  void _filterReviews(String filter) {
    setState(() {
      _selectedFilter = filter;
      _isLoading = true;
    });

    // Simulate network delay
    Future.delayed(const Duration(milliseconds: 500), () {
      setState(() {
        switch (filter) {
          case 'recent':
            _filteredReviews = List.from(_allReviews)
              ..sort((a, b) => (b['timestamp'] as DateTime)
                  .compareTo(a['timestamp'] as DateTime));
            break;
          case 'helpful':
            _filteredReviews = List.from(_allReviews)
              ..sort((a, b) => (b['helpfulCount'] as int)
                  .compareTo(a['helpfulCount'] as int));
            break;
          case 'rating':
            _filteredReviews = List.from(_allReviews)
              ..sort((a, b) => (b['ratings']['overall'] as double)
                  .compareTo(a['ratings']['overall'] as double));
            break;
          case 'solo':
            _filteredReviews = _allReviews
                .where((review) => review['travelerType'] == 'Solo')
                .toList();
            break;
          case 'family':
            _filteredReviews = _allReviews
                .where((review) => review['travelerType'] == 'Family')
                .toList();
            break;
          case 'couple':
            _filteredReviews = _allReviews
                .where((review) => review['travelerType'] == 'Couple')
                .toList();
            break;
          default:
            _filteredReviews = List.from(_allReviews);
        }
        _isLoading = false;
      });
    });
  }

  void _onHelpfulPressed(int reviewId) {
    Fluttertoast.showToast(
      msg: "Thank you for your feedback!",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: AppTheme.lightTheme.colorScheme.primary,
      textColor: Colors.white,
    );
  }

  void _onReportPressed(int reviewId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Report Review'),
        content: const Text(
            'Are you sure you want to report this review as inappropriate?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Fluttertoast.showToast(
                msg: "Review reported successfully",
                toastLength: Toast.LENGTH_SHORT,
                gravity: ToastGravity.BOTTOM,
                backgroundColor: Colors.red,
                textColor: Colors.white,
              );
            },
            child: const Text('Report'),
          ),
        ],
      ),
    );
  }

  void _showWriteReviewBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => WriteReviewBottomSheet(
        onReviewSubmitted: (reviewData) {
          setState(() {
            final newReview = {
              'id': _allReviews.length + 1,
              'userName': 'You',
              'userAvatar':
                  'https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png',
              'visitDate': DateTime.now().day.toString().padLeft(2, '0') +
                  ' ${_getMonthName(DateTime.now().month)} ${DateTime.now().year}',
              'travelerType': 'Solo',
              'reviewText': reviewData['reviewText'],
              'ratings': reviewData['ratings'],
              'photos': reviewData['photos'] ?? [],
              'helpfulCount': 0,
              'hasResponse': false,
              'timestamp': DateTime.now(),
            };
            _allReviews.insert(0, newReview);
            _filteredReviews.insert(0, newReview);
          });

          Fluttertoast.showToast(
            msg: "Review submitted successfully!",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            backgroundColor: AppTheme.lightTheme.colorScheme.primary,
            textColor: Colors.white,
          );
        },
      ),
    );
  }

  String _getMonthName(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[month - 1];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          ReviewsSummaryWidget(summaryData: _summaryData),
          FilterChipsWidget(
            selectedFilter: _selectedFilter,
            onFilterChanged: _filterReviews,
          ),
          SizedBox(height: 1.h),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredReviews.isEmpty
                    ? _buildEmptyState()
                    : _buildReviewsList(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showWriteReviewBottomSheet,
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
        foregroundColor: AppTheme.lightTheme.colorScheme.onPrimary,
        icon: CustomIconWidget(
          iconName: 'edit',
          size: 5.w,
          color: AppTheme.lightTheme.colorScheme.onPrimary,
        ),
        label: Text(
          'Write Review',
          style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
            color: AppTheme.lightTheme.colorScheme.onPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      elevation: 0,
      leading: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: CustomIconWidget(
          iconName: 'arrow_back',
          size: 6.w,
          color: AppTheme.lightTheme.colorScheme.onSurface,
        ),
      ),
      title: Text(
        'Reviews & Ratings',
        style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
      actions: [
        PopupMenuButton<String>(
          onSelected: (value) {
            switch (value) {
              case 'sort_date':
                _filterReviews('recent');
                break;
              case 'sort_rating':
                _filterReviews('rating');
                break;
              case 'sort_helpful':
                _filterReviews('helpful');
                break;
            }
          },
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'sort_date',
              child: Row(
                children: [
                  Icon(Icons.schedule, size: 18),
                  SizedBox(width: 8),
                  Text('Sort by Date'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'sort_rating',
              child: Row(
                children: [
                  Icon(Icons.star, size: 18),
                  SizedBox(width: 8),
                  Text('Sort by Rating'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'sort_helpful',
              child: Row(
                children: [
                  Icon(Icons.thumb_up, size: 18),
                  SizedBox(width: 8),
                  Text('Sort by Helpful'),
                ],
              ),
            ),
          ],
          child: Padding(
            padding: EdgeInsets.all(3.w),
            child: CustomIconWidget(
              iconName: 'sort',
              size: 6.w,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(
          height: 1,
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
    );
  }

  Widget _buildReviewsList() {
    return ListView.builder(
      padding: EdgeInsets.only(bottom: 20.h),
      itemCount: _filteredReviews.length,
      itemBuilder: (context, index) {
        final review = _filteredReviews[index];
        return ReviewCardWidget(
          review: review,
          onHelpfulPressed: () => _onHelpfulPressed(review['id'] as int),
          onReportPressed: () => _onReportPressed(review['id'] as int),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'rate_review',
            size: 20.w,
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          ),
          SizedBox(height: 3.h),
          Text(
            'No reviews found',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Try adjusting your filters or be the first to write a review',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 4.h),
          ElevatedButton.icon(
            onPressed: _showWriteReviewBottomSheet,
            icon: CustomIconWidget(
              iconName: 'edit',
              size: 5.w,
              color: AppTheme.lightTheme.colorScheme.onPrimary,
            ),
            label: const Text('Write First Review'),
          ),
        ],
      ),
    );
  }
}
