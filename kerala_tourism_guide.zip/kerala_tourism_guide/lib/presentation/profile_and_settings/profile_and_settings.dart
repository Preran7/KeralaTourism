import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/favorites_grid.dart';
import './widgets/offline_content_manager.dart';
import './widgets/settings_section.dart';
import './widgets/travel_history_card.dart';
import './widgets/user_profile_header.dart';

class ProfileAndSettings extends StatefulWidget {
  const ProfileAndSettings({Key? key}) : super(key: key);

  @override
  State<ProfileAndSettings> createState() => _ProfileAndSettingsState();
}

class _ProfileAndSettingsState extends State<ProfileAndSettings>
    with TickerProviderStateMixin {
  late TabController _tabController;
  bool _notificationsEnabled = true;
  bool _locationSharingEnabled = true;
  bool _biometricEnabled = false;
  String _selectedLanguage = "English";

  // Mock user data
  final Map<String, dynamic> userData = {
    "name": "Priya Nair",
    "email": "priya.nair@email.com",
    "avatar":
        "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg",
    "memberSince": "March 2023",
    "destinationsVisited": 12,
    "reviewsWritten": 8,
    "favoriteAttractions": 15,
  };

  // Mock travel history data
  final List<Map<String, dynamic>> travelHistory = [
    {
      "id": 1,
      "name": "Munnar Tea Gardens",
      "location": "Munnar, Idukki",
      "image":
          "https://images.pexels.com/photos/4321802/pexels-photo-4321802.jpeg",
      "visitDate": "15 Dec 2024",
      "rating": 4.8,
    },
    {
      "id": 2,
      "name": "Alleppey Backwaters",
      "location": "Alappuzha",
      "image":
          "https://images.pexels.com/photos/3889855/pexels-photo-3889855.jpeg",
      "visitDate": "28 Nov 2024",
      "rating": 4.9,
    },
    {
      "id": 3,
      "name": "Fort Kochi Beach",
      "location": "Kochi, Ernakulam",
      "image":
          "https://images.pexels.com/photos/1450360/pexels-photo-1450360.jpeg",
      "visitDate": "10 Nov 2024",
      "rating": 4.6,
    },
  ];

  // Mock favorites data
  final List<Map<String, dynamic>> favorites = [
    {
      "id": 1,
      "name": "Wayanad Wildlife Sanctuary",
      "location": "Wayanad",
      "image":
          "https://images.pexels.com/photos/1661546/pexels-photo-1661546.jpeg",
      "rating": 4.7,
      "category": "Wildlife",
    },
    {
      "id": 2,
      "name": "Kovalam Beach",
      "location": "Thiruvananthapuram",
      "image":
          "https://images.pexels.com/photos/1450360/pexels-photo-1450360.jpeg",
      "rating": 4.5,
      "category": "Beach",
    },
    {
      "id": 3,
      "name": "Thekkady Spice Gardens",
      "location": "Thekkady, Idukki",
      "image":
          "https://images.pexels.com/photos/4321802/pexels-photo-4321802.jpeg",
      "rating": 4.6,
      "category": "Nature",
    },
    {
      "id": 4,
      "name": "Kumarakom Bird Sanctuary",
      "location": "Kottayam",
      "image":
          "https://images.pexels.com/photos/3889855/pexels-photo-3889855.jpeg",
      "rating": 4.4,
      "category": "Wildlife",
    },
  ];

  // Mock offline content data
  final List<Map<String, dynamic>> offlineContent = [
    {
      "id": 1,
      "title": "Munnar Maps & Guides",
      "icon": "map",
      "iconColor": Colors.blue,
      "size": 45.2,
      "lastUpdated": "2 days ago",
    },
    {
      "id": 2,
      "title": "Malayalam Audio Guides",
      "icon": "headphones",
      "iconColor": Colors.green,
      "size": 128.7,
      "lastUpdated": "1 week ago",
    },
    {
      "id": 3,
      "title": "Kochi Heritage Trail",
      "icon": "account_balance",
      "iconColor": Colors.orange,
      "size": 67.3,
      "lastUpdated": "3 days ago",
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Profile & Settings",
          style: AppTheme.lightTheme.appBarTheme.titleTextStyle,
        ),
        backgroundColor: AppTheme.lightTheme.appBarTheme.backgroundColor,
        foregroundColor: AppTheme.lightTheme.appBarTheme.foregroundColor,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: _showLogoutDialog,
            icon: CustomIconWidget(
              iconName: 'logout',
              color: AppTheme.lightTheme.appBarTheme.foregroundColor!,
              size: 6.w,
            ),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: "Profile"),
            Tab(text: "History"),
            Tab(text: "Favorites"),
            Tab(text: "Settings"),
          ],
          labelColor: AppTheme.lightTheme.primaryColor,
          unselectedLabelColor:
              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          indicatorColor: AppTheme.lightTheme.primaryColor,
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildProfileTab(),
          _buildHistoryTab(),
          _buildFavoritesTab(),
          _buildSettingsTab(),
        ],
      ),
    );
  }

  Widget _buildProfileTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          UserProfileHeader(userData: userData),
          SizedBox(height: 3.h),
          _buildQuickActions(),
          SizedBox(height: 3.h),
          _buildTravelStats(),
        ],
      ),
    );
  }

  Widget _buildHistoryTab() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Travel History",
                  style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                TextButton.icon(
                  onPressed: _exportTravelHistory,
                  icon: CustomIconWidget(
                    iconName: 'download',
                    color: AppTheme.lightTheme.primaryColor,
                    size: 4.w,
                  ),
                  label: const Text("Export"),
                ),
              ],
            ),
          ),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: travelHistory.length,
            itemBuilder: (context, index) {
              return TravelHistoryCard(
                historyItem: travelHistory[index],
                onTap: () => _navigateToAttraction(travelHistory[index]),
              );
            },
          ),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildFavoritesTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(height: 2.h),
          FavoritesGrid(
            favorites: favorites,
            onFavoriteTap: _handleFavoriteTap,
          ),
          SizedBox(height: 3.h),
          _buildSavedItineraries(),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildSettingsTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(height: 2.h),
          SettingsSection(
            title: "Account Settings",
            items: _getAccountSettings(),
            onItemTap: _handleSettingsTap,
          ),
          SizedBox(height: 2.h),
          SettingsSection(
            title: "Privacy & Security",
            items: _getPrivacySettings(),
            onItemTap: _handleSettingsTap,
          ),
          SizedBox(height: 2.h),
          SettingsSection(
            title: "App Preferences",
            items: _getAppPreferences(),
            onItemTap: _handleSettingsTap,
          ),
          SizedBox(height: 2.h),
          OfflineContentManager(
            offlineContent: offlineContent,
            onContentAction: _handleContentAction,
          ),
          SizedBox(height: 2.h),
          SettingsSection(
            title: "Support & Feedback",
            items: _getSupportSettings(),
            onItemTap: _handleSettingsTap,
          ),
          SizedBox(height: 4.h),
        ],
      ),
    );
  }

  Widget _buildQuickActions() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Quick Actions",
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildQuickActionItem(
                "Edit Profile",
                'edit',
                Colors.blue,
                () => _handleSettingsTap("edit_profile"),
              ),
              _buildQuickActionItem(
                "Emergency",
                'emergency',
                Colors.red,
                () => _handleSettingsTap("emergency"),
              ),
              _buildQuickActionItem(
                "Share App",
                'share',
                Colors.green,
                () => _handleSettingsTap("share_app"),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionItem(
    String label,
    String iconName,
    Color color,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 2.h),
        child: Column(
          children: [
            Container(
              width: 12.w,
              height: 12.w,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(
                child: CustomIconWidget(
                  iconName: iconName,
                  color: color,
                  size: 6.w,
                ),
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              label,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTravelStats() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Travel Statistics",
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                    "Total Distance", "1,247 km", 'route', Colors.blue),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildStatCard(
                    "Time Traveled", "89 hours", 'schedule', Colors.orange),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                    "Photos Taken", "342", 'photo_camera', Colors.green),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child:
                    _buildStatCard("Guides Used", "7", 'person', Colors.purple),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(
      String title, String value, String iconName, Color color) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          CustomIconWidget(
            iconName: iconName,
            color: color,
            size: 6.w,
          ),
          SizedBox(height: 1.h),
          Text(
            value,
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            title,
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildSavedItineraries() {
    final itineraries = [
      {
        "name": "Kerala Heritage Trail",
        "duration": "7 days",
        "destinations": 5,
        "image":
            "https://images.pexels.com/photos/4321802/pexels-photo-4321802.jpeg",
      },
      {
        "name": "Backwater Adventure",
        "duration": "3 days",
        "destinations": 3,
        "image":
            "https://images.pexels.com/photos/3889855/pexels-photo-3889855.jpeg",
      },
    ];

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(vertical: 2.h),
            child: Text(
              "Saved Itineraries",
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: AppTheme.lightTheme.primaryColor,
              ),
            ),
          ),
          ...itineraries.map((itinerary) => Container(
                margin: EdgeInsets.only(bottom: 2.h),
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.cardColor,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.05),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: CustomImageWidget(
                        imageUrl: itinerary["image"] as String,
                        width: 15.w,
                        height: 15.w,
                        fit: BoxFit.cover,
                      ),
                    ),
                    SizedBox(width: 3.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            itinerary["name"] as String,
                            style: AppTheme.lightTheme.textTheme.titleSmall
                                ?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 0.5.h),
                          Text(
                            "${itinerary["duration"]} • ${itinerary["destinations"]} destinations",
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () =>
                          Navigator.pushNamed(context, '/itinerary-planner'),
                      icon: CustomIconWidget(
                        iconName: 'arrow_forward',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 5.w,
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  List<Map<String, dynamic>> _getAccountSettings() {
    return [
      {
        "key": "edit_profile",
        "title": "Edit Profile",
        "subtitle": "Update your personal information",
        "icon": "person",
        "iconColor": Colors.blue,
        "hasSwitch": false,
      },
      {
        "key": "change_password",
        "title": "Change Password",
        "subtitle": "Update your account password",
        "icon": "lock",
        "iconColor": Colors.orange,
        "hasSwitch": false,
      },
      {
        "key": "emergency_contacts",
        "title": "Emergency Contacts",
        "subtitle": "Manage emergency contact information",
        "icon": "emergency",
        "iconColor": Colors.red,
        "hasSwitch": false,
      },
    ];
  }

  List<Map<String, dynamic>> _getPrivacySettings() {
    return [
      {
        "key": "location_sharing",
        "title": "Location Sharing",
        "subtitle": "Share location with guides and services",
        "icon": "location_on",
        "iconColor": Colors.green,
        "hasSwitch": true,
        "switchValue": _locationSharingEnabled,
      },
      {
        "key": "review_visibility",
        "title": "Review Visibility",
        "subtitle": "Control who can see your reviews",
        "icon": "visibility",
        "iconColor": Colors.purple,
        "hasSwitch": false,
      },
      {
        "key": "biometric_auth",
        "title": "Biometric Authentication",
        "subtitle": "Use fingerprint or face unlock",
        "icon": "fingerprint",
        "iconColor": Colors.indigo,
        "hasSwitch": true,
        "switchValue": _biometricEnabled,
      },
    ];
  }

  List<Map<String, dynamic>> _getAppPreferences() {
    return [
      {
        "key": "notifications",
        "title": "Notifications",
        "subtitle": "Manage app notifications",
        "icon": "notifications",
        "iconColor": Colors.amber,
        "hasSwitch": true,
        "switchValue": _notificationsEnabled,
      },
      {
        "key": "language",
        "title": "Language",
        "subtitle": "Current: $_selectedLanguage",
        "icon": "language",
        "iconColor": Colors.teal,
        "hasSwitch": false,
      },
      {
        "key": "theme",
        "title": "Theme",
        "subtitle": "App appearance settings",
        "icon": "palette",
        "iconColor": Colors.pink,
        "hasSwitch": false,
      },
      {
        "key": "accessibility",
        "title": "Accessibility",
        "subtitle": "Font size, contrast, voice control",
        "icon": "accessibility",
        "iconColor": Colors.cyan,
        "hasSwitch": false,
      },
    ];
  }

  List<Map<String, dynamic>> _getSupportSettings() {
    return [
      {
        "key": "help_center",
        "title": "Help Center",
        "subtitle": "FAQs and support articles",
        "icon": "help",
        "iconColor": Colors.blue,
        "hasSwitch": false,
      },
      {
        "key": "feedback",
        "title": "Send Feedback",
        "subtitle": "Help us improve the app",
        "icon": "feedback",
        "iconColor": Colors.green,
        "hasSwitch": false,
      },
      {
        "key": "about",
        "title": "About",
        "subtitle": "App version and information",
        "icon": "info",
        "iconColor": Colors.grey,
        "hasSwitch": false,
      },
    ];
  }

  void _handleSettingsTap(String key) {
    switch (key) {
      case "notifications_switch":
        setState(() {
          _notificationsEnabled = !_notificationsEnabled;
        });
        break;
      case "location_sharing_switch":
        setState(() {
          _locationSharingEnabled = !_locationSharingEnabled;
        });
        break;
      case "biometric_auth_switch":
        setState(() {
          _biometricEnabled = !_biometricEnabled;
        });
        break;
      case "language":
        _showLanguageDialog();
        break;
      case "emergency":
      case "emergency_contacts":
        _showEmergencyContacts();
        break;
      case "edit_profile":
        _showEditProfileDialog();
        break;
      case "feedback":
        _showFeedbackDialog();
        break;
      case "share_app":
        _shareApp();
        break;
      default:
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Opening $key..."),
            duration: const Duration(seconds: 1),
          ),
        );
    }
  }

  void _handleFavoriteTap(Map<String, dynamic> favorite) {
    if (favorite.isEmpty) {
      // Navigate to full favorites list
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Opening full favorites list...")),
      );
    } else {
      Navigator.pushNamed(context, '/attraction-details');
    }
  }

  void _handleContentAction(String action) {
    switch (action) {
      case "cleanup":
        _showCleanupDialog();
        break;
      case "download_more":
        _showDownloadDialog();
        break;
      default:
        if (action.startsWith("delete_")) {
          final id = action.split("_")[1];
          _deleteOfflineContent(id);
        }
    }
  }

  void _navigateToAttraction(Map<String, dynamic> attraction) {
    Navigator.pushNamed(context, '/attraction-details');
  }

  void _exportTravelHistory() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Exporting travel history...")),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Logout"),
        content: const Text("Are you sure you want to logout?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Handle logout
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Logged out successfully")),
              );
            },
            child: const Text("Logout"),
          ),
        ],
      ),
    );
  }

  void _showLanguageDialog() {
    final languages = ["English", "Malayalam", "Hindi", "Tamil"];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Select Language"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: languages
              .map((language) => RadioListTile<String>(
                    title: Text(language),
                    value: language,
                    groupValue: _selectedLanguage,
                    onChanged: (value) {
                      setState(() {
                        _selectedLanguage = value!;
                      });
                      Navigator.pop(context);
                    },
                  ))
              .toList(),
        ),
      ),
    );
  }

  void _showEmergencyContacts() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Emergency Contacts"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Kerala Tourism Helpline: 0471-2321132"),
            const Text("Police: 100"),
            const Text("Ambulance: 108"),
            const Text("Fire: 101"),
            SizedBox(height: 2.h),
            const Text("Your Emergency Contact:"),
            const Text("John Doe: +91 9876543210"),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Close"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content: Text("Opening emergency contact editor...")),
              );
            },
            child: const Text("Edit"),
          ),
        ],
      ),
    );
  }

  void _showEditProfileDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Edit Profile"),
        content: const Text("Profile editing feature will be available soon."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Close"),
          ),
        ],
      ),
    );
  }

  void _showFeedbackDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Send Feedback"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const TextField(
              decoration: InputDecoration(
                hintText: "Share your feedback...",
                border: OutlineInputBorder(),
              ),
              maxLines: 4,
            ),
            SizedBox(height: 2.h),
            const Text(
              "Your feedback helps Kerala Tourism improve services.",
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content:
                        Text("Feedback sent to Kerala Tourism Department")),
              );
            },
            child: const Text("Send"),
          ),
        ],
      ),
    );
  }

  void _shareApp() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Sharing Kerala Tourism Guide app...")),
    );
  }

  void _showCleanupDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Clean Up Storage"),
        content: const Text(
            "This will remove old cached data and free up space. Continue?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content: Text("Storage cleaned up successfully")),
              );
            },
            child: const Text("Clean Up"),
          ),
        ],
      ),
    );
  }

  void _showDownloadDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Download Content"),
        content: const Text("Select content to download for offline use."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Opening download manager...")),
              );
            },
            child: const Text("Browse"),
          ),
        ],
      ),
    );
  }

  void _deleteOfflineContent(String id) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Delete Content"),
        content:
            const Text("Are you sure you want to delete this offline content?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Content deleted successfully")),
              );
            },
            child: const Text("Delete"),
          ),
        ],
      ),
    );
  }
}
